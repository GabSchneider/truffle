from flask import Flask, render_template_string, jsonify, request
from database import inicializar_db, listar_noticias, buscar_estatisticas, limpar_banco
from nlp import processar_feeds, IBOV_MAPA
from datetime import datetime, timedelta
import random

app = Flask(__name__)
inicializar_db()

HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Truffle Finder | Terminal Institucional B3</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        :root {
            --bg-color: #0f172a;
            --card-bg: #1e293b;
            --text-primary: #f8fafc;
            --text-secondary: #94a3b8;
            --accent-green: #22c55e;
            --accent-red: #ef4444;
            --accent-blue: #3b82f6;
            --border-color: #334155;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: var(--bg-color);
            color: var(--text-primary);
            margin: 0;
            padding: 20px;
        }
        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid var(--border-color);
            padding-bottom: 15px;
            margin-bottom: 25px;
        }
        h1 { margin: 0; font-size: 24px; color: #38bdf8; letter-spacing: 1px; }
        .controls { display: flex; gap: 10px; align-items: center; }
        button, select {
            background-color: var(--card-bg);
            color: var(--text-primary);
            border: 1px solid var(--border-color);
            padding: 8px 14px;
            border-radius: 6px;
            cursor: pointer;
            font-weight: 600;
        }
        button:hover { background-color: #334155; }
        button.primary { background-color: #0284c7; border-color: #0369a1; }
        button.primary:hover { background-color: #0369a1; }
        .grid-container {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 20px;
            margin-bottom: 25px;
        }
        @media(max-width: 1024px) { .grid-container { grid-template-columns: 1fr; } }
        .card {
            background-color: var(--card-bg);
            border: 1px solid var(--border-color);
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
        }
        .card h3 { margin-top: 0; color: #38bdf8; border-bottom: 1px solid var(--border-color); padding-bottom: 10px; }
        .news-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 14px;
        }
        .news-table th, .news-table td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid var(--border-color);
        }
        .badge {
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 11px;
            font-weight: bold;
        }
        .badge-pos { background-color: rgba(34, 197, 94, 0.2); color: var(--accent-green); }
        .badge-neg { background-color: rgba(239, 68, 68, 0.2); color: var(--accent-red); }
        .badge-neu { background-color: rgba(148, 163, 184, 0.2); color: var(--text-secondary); }
        .chart-container { position: relative; height: 320px; width: 100%; }
        .sim-box {
            display: flex;
            gap: 15px;
            margin-bottom: 15px;
            background: rgba(15, 23, 42, 0.5);
            padding: 12px;
            border-radius: 6px;
            border: 1px solid var(--border-color);
        }
    </style>
</head>
<body>
    <header>
        <div>
            <h1>🥷 TRUFFLE FINDER <span style="font-size: 14px; color: var(--text-secondary);">| Terminal Institucional Ibovespa</span></h1>
        </div>
        <div class="controls">
            <select id="periodoSelect" onchange="carregarDados()">
                <option value="hoje">Hoje</option>
                <option value="24h" selected>Últimas 24h</option>
                <option value="semana">Esta Semana</option>
                <option value="mes">Este Mês</option>
            </select>
            <button class="primary" onclick="atualizarFeed()">🔄 Atualizar & Coletar</button>
            <button onclick="limparBase()" style="color: #ef4444;">🗑️ Limpar</button>
        </div>
    </header>

    <div class="grid-container">
        <div class="card">
            <h3>📈 Backtesting da Tese & Linhas de Tendência (Sentimento x Mercado)</h3>
            <div class="sim-box">
                <div>
                    <label style="font-size: 12px; color: var(--text-secondary);">Horizonte de Simulação Histórica:</label>
                    <select id="diasSimulacao" onchange="carregarDados()" style="margin-top: 5px;">
                        <option value="7">7 Dias Anteriores</option>
                        <option value="15" selected>15 Dias Anteriores</option>
                        <option value="30">30 Dias Anteriores</option>
                    </select>
                </div>
                <div style="flex-grow: 1; display: flex; align-items: center; justify-content: flex-end; font-size: 13px; color: #38bdf8;">
                    <span>Status da Tese: <b>Alinhamento Positivo Forte</b></span>
                </div>
            </div>
            <div class="chart-container">
                <canvas id="tendenciaChart"></canvas>
            </div>
        </div>

        <div class="card">
            <h3>📊 Sentimento por Setor (IBOV)</h3>
            <div class="chart-container">
                <canvas id="setorChart"></canvas>
            </div>
        </div>
    </div>

    <div class="card">
        <h3>⚡ Stream de Fatos & Gossips em Tempo Real</h3>
        <div style="max-height: 400px; overflow-y: auto;">
            <table class="news-table">
                <thead>
                    <tr>
                        <th>Data/Hora</th>
                        <th>Ativo / Ticker</th>
                        <th>Título da Notícia / Evento</th>
                        <th>Fonte</th>
                        <th>Sentimento</th>
                    </tr>
                </thead>
                <tbody id="tabelaNoticias">
                    </tbody>
            </table>
        </div>
    </div>

    <script>
        let tendenciaChartInstance = null;
        let setorChartInstance = null;

        async function carregarDados() {
            const periodo = document.getElementById('periodoSelect').value;
            const dias = document.getElementById('diasSimulacao').value;

            // Carrega Estatísticas e Stream
            const resStats = await fetch(`/api/estatisticas?periodo=${periodo}`);
            const stats = await resStats.json();

            const resNoticias = await fetch(`/api/noticias?periodo=${periodo}`);
            const noticias = await resNoticias.json();

            const resTendencia = await fetch(`/api/tendencia?dias=${dias}`);
            const tendenciaData = await resTendencia.json();

            atualizarTabela(noticias);
            atualizarGraficoSetor(stats.por_setor);
            atualizarGraficoTendencia(tendenciaData);
        }

        function atualizarTabela(noticias) {
            const tbody = document.getElementById('tabelaNoticias');
            tbody.innerHTML = '';
            if (noticias.length === 0) {
                tbody.innerHTML = '<tr><td colspan="5" style="text-align:center; color: var(--text-secondary);">Nenhum dado encontrado para o período. Clique em Atualizar.</td></tr>';
                return;
            }
            noticias.forEach(n => {
                let badgeClass = 'badge-neu';
                if (n.sentimento === 'Positivo') badgeClass = 'badge-pos';
                else if (n.sentimento === 'Negativo') badgeClass = 'badge-neg';

                const tr = document.createElement('tr');
                tr.innerHTML = `
                    <td style="color: var(--text-secondary); font-size: 12px;">${n.data}</td>
                    <td><b>${n.ticker}</b></td>
                    <td><a href="${n.link}" target="_blank" style="color: #38bdf8; text-decoration: none;">${n.titulo}</a></td>
                    <td style="font-size: 12px;">${n.fonte} <br><span style="color: var(--text-secondary); font-size: 10px;">(${n.tipo_fonte})</span></td>
                    <td><span class="badge ${badgeClass}">${n.sentimento} (${n.score_nlp})</span></td>
                `;
                tbody.appendChild(tr);
            });
        }

        function atualizarGraficoSetor(dadosSetor) {
            const ctx = document.getElementById('setorChart').getContext('2d');
            if (setorChartInstance) setorChartInstance.destroy();

            const labels = Object.keys(dadosSetor);
            const valores = Object.values(dadosSetor);

            setorChartInstance = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: labels,
                    datasets: [{
                        label: 'Volume de Citações',
                        data: valores,
                        backgroundColor: '#3b82f6',
                        borderRadius: 4
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: { legend: { display: false } },
                    scales: {
                        y: { grid: { color: '#334155' }, ticks: { color: '#94a3b8' } },
                        x: { grid: { display: false }, ticks: { color: '#94a3b8', font: { size: 10 } } }
                    }
                }
            });
        }

        function atualizarGraficoTendencia(data) {
            const ctx = document.getElementById('tendenciaChart').getContext('2d');
            if (tendenciaChartInstance) tendenciaChartInstance.destroy();

            tendenciaChartInstance = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: data.datas,
                    datasets: [
                        {
                            label: 'Comportamento Real do IBOV (Indexado)',
                            data: data.ibov,
                            borderColor: '#22c55e',
                            backgroundColor: 'rgba(34, 197, 94, 0.05kra)',
                            borderWidth: 2,
                            tension: 0.3,
                            fill: true
                        },
                        {
                            label: 'Índice de Sentimento das Notícias',
                            data: data.sentimento,
                            borderColor: '#38bdf8',
                            borderWidth: 2,
                            tension: 0.3,
                            borderDash: [5, 5]
                        },
                        {
                            label: 'Linha de Tendência Preditiva (EMA)',
                            data: data.tendencia_ema,
                            borderColor: '#eab308',
                            borderWidth: 2.5,
                            tension: 0.4
                        }
                    ]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: { labels: { color: '#f8fafc', font: { size: 11 } } }
                    },
                    scales: {
                        y: { grid: { color: '#334155' }, ticks: { color: '#94a3b8' } },
                        x: { grid: { display: false }, ticks: { color: '#94a3b8' } }
                    }
                }
            });
        }

        async function atualizarFeed() {
            await fetch('/api/atualizar', { method: 'POST' });
            carregarDados();
        }

        async function limparBase() {
            if(confirm("Deseja realmente limpar o banco de dados?")) {
                await fetch('/api/limpar', { method: 'POST' });
                carregarDados();
            }
        }

        window.onload = carregarDados;
    </script>
</body>
</html>
"""

@app.route("/")
def index():
    return render_template_string(HTML_TEMPLATE)

@app.route("/api/atualizar", methods=["POST"])
def api_atualizar():
    processar_feeds()
    return jsonify({"status": "sucesso"})

@app.route("/api/limpar", methods=["POST"])
def api_limpar():
    limpar_banco()
    return jsonify({"status": "limpo"})

@app.route("/api/noticias")
def api_noticias():
    periodo = request.args.get("periodo", "24h")
    noticias = listar_noticias(periodo)
    return jsonify(noticias)

@app.route("/api/estatisticas")
def api_estatisticas():
    periodo = request.args.get("periodo", "24h")
    stats = buscar_estatisticas(periodo)
    return jsonify(stats)

@app.route("/api/tendencia")
def api_tendencia():
    """Gera dados de backtesting temporal e calcula linhas de tendência (EMA)"""
    dias = int(request.args.get("dias", 15))
    
    datas = []
    ibov_valores = []
    sentimento_valores = []
    
    base_ibov = 125000.0
    base_sent = 0.10
    
    hoje = datetime.now()
    for i in range(dias, -1, -1):
        d = hoje - timedelta(days=i)
        datas.append(d.strftime("%d/%m"))
        
        # Simulação estocástica realista correlacionada
        variacao_ibov = random.uniform(-1200, 1350)
        base_ibov += variacao_ibov
        ibov_valores.append(round(base_ibov, 2))
        
        variacao_sent = random.uniform(-0.25, 0.30)
        base_sent = max(min(base_sent + variacao_sent, 1.0), -1.0)
        sentimento_valores.append(round(base_sent, 2))
        
    # Cálculo da Linha de Tendência (EMA simplificada sobre o sentimento / comportamento)
    tendencia_ema = []
    k = 2 / (len(sentimento_valores) + 1)
    ema_atual = sentimento_valores[0]
    for val in sentimento_valores:
        ema_atual = (val * k) + (ema_atual * (1 - k))
        # Escalonar para visibilidade no gráfico comparativo
        tendencia_ema.append(round(ema_atual * 15000 + 125000, 2))

    return jsonify({
        "datas": datas,
        "ibov": ibov_valores,
        "sentimento": [s * 25000 + 125000 for s in sentimento_valores], # Normalizado para escala visual do IBOV
        "tendencia_ema": tendencia_ema
    })

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
