from fastapi import FastAPI, HTTPException
from fastapi.responses import HTMLResponse
import feedparser
from datetime import datetime
import sqlite3

app = FastAPI(title="Truffle Finder - Terminal Ibovespa Oficial", version="6.0")

DB_FILE = "truffle_history.db"

def init_db():
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS noticias (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            titulo TEXT UNIQUE,
            fonte TEXT,
            data TEXT,
            link TEXT,
            ticker TEXT,
            setor TEXT,
            sentimento TEXT,
            criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    conn.commit()
    conn.close()

init_db()

IBOV_MAPA = {
    "PETR4": {"nome": "Petrobras PN", "setor": "Petróleo, Gás e Biocombustíveis"},
    "PETR3": {"nome": "Petrobras ON", "setor": "Petróleo, Gás e Biocombustíveis"},
    "VALE3": {"nome": "Vale", "setor": "Mineração / Materiais Básicos"},
    "ITUB4": {"nome": "Itaú Unibanco", "setor": "Financeiro"},
    "BBDC4": {"nome": "Bradesco", "setor": "Financeiro"},
    "BBAS3": {"nome": "Banco do Brasil", "setor": "Financeiro"},
    "SANB11": {"nome": "Santander Brasil", "setor": "Financeiro"},
    "B3SA3": {"nome": "B3 S.A.", "setor": "Serviços Financeiros Diversos"},
    "ABEV3": {"nome": "Ambev", "setor": "Consumo Não Cíclico"},
    "MGLU3": {"nome": "Magazine Luiza", "setor": "Consumo Cíclico"},
    "RENT3": {"nome": "Localiza", "setor": "Consumo Cíclico"},
    "WEGE3": {"nome": "Weg", "setor": "Bens Industriais"},
    "SUZB3": {"nome": "Suzano", "setor": "Papel e Celulose"},
    "JBSS3": {"nome": "JBS", "setor": "Consumo Não Cíclico"},
    "PRIO3": {"nome": "Prio", "setor": "Petróleo, Gás e Biocombustíveis"},
    "ELET3": {"nome": "Eletrobras", "setor": "Utilidade Pública"},
    "EQTL3": {"nome": "Equatorial", "setor": "Utilidade Pública"},
    "CPLE6": {"nome": "Copel", "setor": "Utilidade Pública"}
}

RSS_FEEDS = [
    "https://infomoney.com.br/feed/",
    "https://valor.globo.com/rss/"
]

def analisar_sentimento(texto: str) -> str:
    texto_lower = texto.lower()
    positivas = ["alta", "lucro", "crescimento", "disparou", "positivo", "superou", "recorde", "expansão", "dividendo", "valorização", "avanço"]
    negativas = ["queda", "prejuízo", "crise", "despencou", "negativo", "investigação", "falência", "corte", "processo", "retração"]
    
    score = 0
    for p in positivas:
        if p in texto_lower: score += 1
    for n in negativas:
        if n in texto_lower: score -= 1
            
    if score > 0: return "Positivo"
    elif score < 0: return "Negativo"
    return "Neutro"

def sincronizar_feeds():
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    
    for url_feed in RSS_FEEDS:
        try:
            feed = feedparser.parse(url_feed)
            for entry in feed.entries[:30]:
                titulo = entry.get("title", "")
                link = entry.get("link", "")
                data_pub = entry.get("published", str(datetime.now()))[:16]
                
                ticker_encontrado = "IBOV / MERCADO"
                setor_encontrado = "Índice Bovespa"
                
                for ticker, info in IBOV_MAPA.items():
                    if ticker.lower() in titulo.lower() or info["nome"].lower() in titulo.lower():
                        ticker_encontrado = ticker
                        setor_encontrado = info["setor"]
                        break
                
                sentimento = analisar_sentimento(titulo)
                fonte_nome = "InfoMoney" if "infomoney" in url_feed else "Valor Econômico"
                
                try:
                    cursor.execute('''
                        INSERT INTO noticias (titulo, fonte, data, link, ticker, setor, sentimento)
                        VALUES (?, ?, ?, ?, ?, ?, ?)
                    ''', (titulo, fonte_nome, data_pub, link, ticker_encontrado, setor_encontrado, sentimento))
                except sqlite3.IntegrityError:
                    pass
        except Exception:
            continue
            
    conn.commit()
    conn.close()

@app.get("/api/noticias")
def obter_noticias(ticker: str = None):
    sincronizar_feeds()
    
    conn = sqlite3.connect(DB_FILE)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    
    if ticker and ticker != "TODOS":
        cursor.execute("SELECT * FROM noticias WHERE ticker = ? ORDER BY id DESC LIMIT 50", (ticker,))
    else:
        cursor.execute("SELECT * FROM noticias ORDER BY id DESC LIMIT 50")
        
    rows = cursor.fetchall()
    noticias = [dict(row) for row in rows]
    conn.close()
    
    return {
        "status": "sucesso", 
        "total_empresas": len(IBOV_MAPA), 
        "total_historico": len(noticias), 
        "noticias": noticias
    }

@app.get("/", response_class=HTMLResponse)
def dashboard():
    return """
    <!DOCTYPE html>
    <html lang="pt-BR">
    <head>
        <meta charset="UTF-8">
        <title>Truffle Finder - Terminal Institucional Ibovespa</title>
        <script src="https://cdn.tailwindcss.com"></script>
    </head>
    <body class="bg-slate-950 text-slate-100 font-sans p-6">
        <div class="max-w-7xl mx-auto">
            <header class="flex justify-between items-center mb-8 border-b border-slate-800 pb-4">
                <div class="flex items-center gap-4">
                    <div class="bg-gradient-to-br from-blue-600/30 to-blue-900/40 p-2.5 rounded-2xl border border-blue-500/40 shadow-lg flex items-center justify-center">
                        <span class="text-3xl">🐷</span>
                    </div>
                    <div>
                        <div class="flex items-center gap-2">
                            <h1 class="text-2xl font-black tracking-wider text-white">TRUFFLE<span class="text-blue-500">FINDER</span></h1>
                        </div>
                        <p class="text-[11px] text-slate-400 uppercase tracking-widest font-medium">Intelligence Terminal • B3 & Ibovespa</p>
                    </div>
                </div>

                <div class="flex items-center gap-3">
                    <span class="inline-flex items-center gap-2 bg-emerald-950/80 text-emerald-400 px-3.5 py-1.5 rounded-full text-xs font-semibold border border-emerald-800 shadow-inner">
                        <span class="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span> Sistema Ativo (Porta 8002)
                    </span>
                </div>
            </header>

            <div class="bg-slate-900 p-4 rounded-xl border border-slate-800 mb-6 flex flex-wrap gap-2 items-center shadow-lg">
                <span class="text-xs font-semibold text-slate-400 uppercase tracking-wider mr-2">Filtro de Ativos:</span>
                <button onclick="filtrarTicker('TODOS')" class="px-3.5 py-1.5 rounded-lg text-xs font-semibold bg-blue-600 text-white transition filter-btn shadow" data-ticker="TODOS">🌐 Todos</button>
                <button onclick="filtrarTicker('PETR4')" class="px-3.5 py-1.5 rounded-lg text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-300 transition filter-btn" data-ticker="PETR4">⚡ PETR4</button>
                <button onclick="filtrarTicker('VALE3')" class="px-3.5 py-1.5 rounded-lg text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-300 transition filter-btn" data-ticker="VALE3">⛏️ VALE3</button>
                <button onclick="filtrarTicker('ITUB4')" class="px-3.5 py-1.5 rounded-lg text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-300 transition filter-btn" data-ticker="ITUB4">🏦 ITUB4</button>
                <button onclick="filtrarTicker('BBDC4')" class="px-3.5 py-1.5 rounded-lg text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-300 transition filter-btn" data-ticker="BBDC4">💳 BBDC4</button>
                <button onclick="filtrarTicker('ABEV3')" class="px-3.5 py-1.5 rounded-lg text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-300 transition filter-btn" data-ticker="ABEV3">🍺 ABEV3</button>
                <button onclick="filtrarTicker('MGLU3')" class="px-3.5 py-1.5 rounded-lg text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-300 transition filter-btn" data-ticker="MGLU3">🛍️ MGLU3</button>
                <button onclick="filtrarTicker('WEGE3')" class="px-3.5 py-1.5 rounded-lg text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-300 transition filter-btn" data-ticker="WEGE3">⚙️ WEGE3</button>
                <button onclick="filtrarTicker('SUZB3')" class="px-3.5 py-1.5 rounded-lg text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-300 transition filter-btn" data-ticker="SUZB3">🌲 SUZB3</button>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                <div class="bg-slate-900 p-6 rounded-xl border border-slate-800 shadow-lg">
                    <h3 class="text-slate-400 text-xs uppercase tracking-wider font-semibold">Empresas Mapeadas</h3>
                    <p id="total-empresas" class="text-3xl font-bold text-white mt-2">Carregando...</p>
                </div>
                <div class="bg-slate-900 p-6 rounded-xl border border-slate-800 shadow-lg">
                    <h3 class="text-slate-400 text-xs uppercase tracking-wider font-semibold">Registos na Base</h3>
                    <p id="total-noticias" class="text-3xl font-bold text-blue-400 mt-2">Carregando...</p>
                </div>
                <div class="bg-slate-900 p-6 rounded-xl border border-slate-800 shadow-lg">
                    <h3 class="text-slate-400 text-xs uppercase tracking-wider font-semibold">Filtro Ativo</h3>
                    <p id="filtro-ativo-txt" class="text-2xl font-bold text-emerald-400 mt-2">TODOS</p>
                </div>
            </div>

            <div class="bg-slate-900 rounded-xl border border-slate-800 p-6 shadow-xl">
                <div class="flex justify-between items-center mb-6">
                    <h2 class="text-lg font-bold text-slate-200">Fluxo de Notícias & NLP (Ibovespa)</h2>
                    <button onclick="carregarDados(tickerAtual)" class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-xs font-semibold transition shadow">Atualizar Dados</button>
                </div>
                <div class="overflow-x-auto">
                    <table class="w-full text-left border-collapse">
                        <thead>
                            <tr class="border-b border-slate-800 text-slate-400 text-xs uppercase tracking-wider">
                                <th class="p-3">Data / Hora</th>
                                <th class="p-3">Ticker</th>
                                <th class="p-3">Setor</th>
                                <th class="p-3">Título da Notícia</th>
                                <th class="p-3">Sentimento (NLP)</th>
                            </tr>
                        </thead>
                        <tbody id="tabela-noticias" class="divide-y divide-slate-800/60 text-sm">
                            <tr><td colspan="5" class="p-6 text-center text-slate-500">A carregar dados do mercado...</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <script>
            let tickerAtual = 'TODOS';

            async function carregarDados(ticker = 'TODOS') {
                tickerAtual = ticker;
                document.getElementById('filtro-ativo-txt').innerText = ticker;
                
                document.querySelectorAll('.filter-btn').forEach(btn => {
                    if(btn.getAttribute('data-ticker') === ticker) {
                        btn.className = "px-3.5 py-1.5 rounded-lg text-xs font-semibold bg-blue-600 text-white transition filter-btn shadow";
                    } else {
                        btn.className = "px-3.5 py-1.5 rounded-lg text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-300 transition filter-btn";
                    }
                });

                try {
                    let url = '/api/noticias';
                    if(ticker !== 'TODOS') url += `?ticker=${ticker}`;
                    
                    const res = await fetch(url);
                    const data = await res.json();
                    
                    document.getElementById('total-empresas').innerText = data.total_empresas + " Ativos";
                    document.getElementById('total-noticias').innerText = data.total_historico + " Registos";
                    
                    const tbody = document.getElementById('tabela-noticias');
                    tbody.innerHTML = '';
                    
                    if(data.noticias.length === 0) {
                        tbody.innerHTML = '<tr><td colspan="5" class="p-6 text-center text-slate-500">Nenhum registo encontrado para este filtro.</td></tr>';
                        return;
                    }
                    
                    data.noticias.forEach(n => {
                        let badgeColor = 'bg-slate-800 text-slate-300 border-slate-700';
                        if(n.sentimento === 'Positivo') badgeColor = 'bg-emerald-950 text-emerald-400 border-emerald-800';
                        if(n.sentimento === 'Negativo') badgeColor = 'bg-rose-950 text-rose-400 border-rose-800';
                        
                        const tr = document.createElement('tr');
                        tr.className = 'hover:bg-slate-800/40 transition';
                        tr.innerHTML = `
                            <td class="p-3 text-slate-400 text-xs whitespace-nowrap">${n.data}</td>
                            <td class="p-3 font-mono font-bold text-blue-400">${n.ticker}</td>
                            <td class="p-3 text-slate-300 text-xs">${n.setor}</td>
                            <td class="p-3"><a href="${n.link}" target="_blank" class="hover:text-blue-400 transition text-slate-100">${n.titulo}</a></td>
                            <td class="p-3"><span class="px-3 py-1 rounded-full text-xs font-semibold border ${badgeColor}">${n.sentimento}</span></td>
                        `;
                        tbody.appendChild(tr);
                    });
                } catch (err) {
                    console.error("Erro ao carregar dados:", err);
                }
            }

            function filtrarTicker(ticker) {
                carregarDados(ticker);
            }

            carregarDados('TODOS');
        </script>
    </body>
    </html>
    """
