import sqlite3
from datetime import datetime, timedelta

DB_FILE = "truffle_institutional.db"

def init_db():
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS noticias (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            titulo TEXT UNIQUE,
            fonte TEXT,
            tipo_fonte TEXT,
            data TEXT,
            link TEXT,
            ticker TEXT,
            setor TEXT,
            subsetor TEXT,
            sentimento TEXT,
            score_nlp REAL,
            criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS preferencias (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT,
            setor_alerta TEXT,
            sensibilidade TEXT
        )
    ''')
    cursor.execute("SELECT COUNT(*) FROM preferencias")
    if cursor.fetchone()[0] == 0:
        cursor.execute("INSERT INTO preferencias (email, setor_alerta, sensibilidade) VALUES (?, ?, ?)", 
                       ("gestor@trufflefinder.com.br", "Financeiro", "Alta"))
    conn.commit()
    conn.close()

def salvar_noticia(n):
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    try:
        cursor.execute('''
            INSERT INTO noticias (titulo, fonte, tipo_fonte, data, link, ticker, setor, subsetor, sentimento, score_nlp, criado_em)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            n["titulo"], n["fonte"], n["tipo_fonte"], n["data"], n["link"], 
            n["ticker"], n["setor"], n["subsetor"], n["sentimento"], n["score_nlp"], 
            n.get("criado_em", datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
        ))
        conn.commit()
    except sqlite3.IntegrityError:
        pass
    conn.close()

def popular_massa_cruzada():
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    cursor.execute("SELECT COUNT(*) FROM noticias")
    total = cursor.fetchone()[0]
    
    if total < 25:
        agora = datetime.now()
        massa = [
            # Petrobras (PETR4) - Fatos vs Gossip
            {
                "titulo": "Petrobras (PETR4) anuncia formalmente alta na produção do pré-sal em fato relevante", 
                "fonte": "Valor Econômico", "tipo_fonte": "Fato (Confiável)", 
                "data": (agora - timedelta(hours=1)).strftime("%d/%m %H:%M"), "link": "https://valor.globo.com", 
                "ticker": "PETR4", "setor": "Petróleo, Gás e Biocombustíveis", "subsetor": "Exploração e Produção", 
                "sentimento": "Positivo", "score_nlp": 0.85, "criado_em": agora.strftime("%Y-%m-%d %H:%M:%S")
            },
            {
                "titulo": "Rumor de bastidor aponta troca iminente na diretoria financeira da Petrobras (PETR4)", 
                "fonte": "X / Fórum Corporativo", "tipo_fonte": "Gossip (Rumor)", 
                "data": (agora - timedelta(hours=3)).strftime("%d/%m %H:%M"), "link": "https://twitter.com", 
                "ticker": "PETR4", "setor": "Petróleo, Gás e Biocombustíveis", "subsetor": "Exploração e Produção", 
                "sentimento": "Negativo", "score_nlp": -0.60, "criado_em": agora.strftime("%Y-%m-%d %H:%M:%S")
            },
            
            # Vale (VALE3) - Fatos vs Gossip
            {
                "titulo": "Vale (VALE3) reporta queda nos embarques de minério de ferro para a Ásia", 
                "fonte": "InfoMoney", "tipo_fonte": "Fato (Confiável)", 
                "data": (agora - timedelta(hours=2)).strftime("%d/%m %H:%M"), "link": "https://infomoney.com.br", 
                "ticker": "VALE3", "setor": "Materiais Básicos", "subsetor": "Mineração", 
                "sentimento": "Negativo", "score_nlp": -0.70, "criado_em": agora.strftime("%Y-%m-%d %H:%M:%S")
            },
            {
                "titulo": "Especulação no mercado sugere fusão de braço logístico da Vale (VALE3)", 
                "fonte": "Reddit / Fóruns de Investidores", "tipo_fonte": "Gossip (Rumor)", 
                "data": (agora - timedelta(days=1)).strftime("%d/%m %H:%M"), "link": "https://reddit.com", 
                "ticker": "VALE3", "setor": "Materiais Básicos", "subsetor": "Mineração", 
                "sentimento": "Positivo", "score_nlp": 0.50, "criado_em": (agora - timedelta(days=1)).strftime("%Y-%m-%d %H:%M:%S")
            },

            # Itaú Unibanco (ITUB4)
            {
                "titulo": "Itaú Unibanco (ITUB4) reporta expansão sólida da carteira de crédito corporativo", 
                "fonte": "Valor Econômico", "tipo_fonte": "Fato (Confiável)", 
                "data": (agora - timedelta(hours=4)).strftime("%d/%m %H:%M"), "link": "https://valor.globo.com", 
                "ticker": "ITUB4", "setor": "Financeiro", "subsetor": "Bancos Comerciais", 
                "sentimento": "Positivo", "score_nlp": 0.80, "criado_em": agora.strftime("%Y-%m-%d %H:%M:%S")
            },

            # Magazine Luiza (MGLU3)
            {
                "titulo": "Magazine Luiza (MGLU3) enfrenta pressões com custos operacionais e juros", 
                "fonte": "Exame", "tipo_fonte": "Fato (Confiável)", 
                "data": (agora - timedelta(hours=5)).strftime("%d/%m %H:%M"), "link": "https://exame.com", 
                "ticker": "MGLU3", "setor": "Consumo Cíclico", "subsetor": "Varejo Digital", 
                "sentimento": "Negativo", "score_nlp": -0.75, "criado_em": agora.strftime("%Y-%m-%d %H:%M:%S")
            },
            {
                "titulo": "Boatos na rede indicam possível injeção de capital de parceiro estratégico na MGLU3", 
                "fonte": "X / Especulação de Mercado", "tipo_fonte": "Gossip (Rumor)", 
                "data": (agora - timedelta(days=2)).strftime("%d/%m %H:%M"), "link": "https://twitter.com", 
                "ticker": "MGLU3", "setor": "Consumo Cíclico", "subsetor": "Varejo Digital", 
                "sentimento": "Positivo", "score_nlp": 0.65, "criado_em": (agora - timedelta(days=2)).strftime("%Y-%m-%d %H:%M:%S")
            }
        ]
        for m in massa:
            salvar_noticia(m)
    conn.close()

init_db()
popular_massa_cruzada()

def buscar_dados_completos(ticker=None, periodo="TODOS", tipo_fonte="TODOS"):
    conn = sqlite3.connect(DB_FILE)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    
    query = "SELECT * FROM noticias WHERE 1=1"
    params = []
    
    if ticker and ticker != "TODOS":
        query += " AND ticker = ?"
        params.append(ticker)
        
    if tipo_fonte and tipo_fonte != "TODOS":
        if tipo_fonte == "FATOS":
            query += " AND tipo_fonte LIKE ?"
            params.append("%Fato%")
        elif tipo_fonte == "GOSSIP":
            query += " AND tipo_fonte LIKE ?"
            params.append("%Gossip%")

    if periodo == "HOJE":
        hoje_str = datetime.now().strftime("%Y-%m-%d")
        query += " AND criado_em LIKE ?"
        params.append(f"{hoje_str}%")
    elif periodo == "24H":
        limite_24h = (datetime.now() - timedelta(hours=24)).strftime("%Y-%m-%d %H:%M:%S")
        query += " AND criado_em >= ?"
        params.append(limite_24h)
    elif periodo == "SEMANA":
        limite_semana = (datetime.now() - timedelta(days=7)).strftime("%Y-%m-%d")
        query += " AND criado_em >= ?"
        params.append(limite_semana)

    query += " ORDER BY id DESC LIMIT 50"
    
    cursor.execute(query, params)
    rows = cursor.fetchall()
    noticias = [dict(r) for r in rows]

    cursor.execute("SELECT COUNT(*) FROM noticias")
    total = cursor.fetchone()[0]
    cursor.execute("SELECT COUNT(*) FROM noticias WHERE sentimento='Positivo'")
    pos = cursor.fetchone()[0]
    cursor.execute("SELECT COUNT(*) FROM noticias WHERE sentimento='Negativo'")
    neg = cursor.fetchone()[0]
    
    # Contadores específicos para o Termômetro Facto vs Gossip
    cursor.execute("SELECT COUNT(*) FROM noticias WHERE tipo_fonte LIKE '%Fato%'")
    total_fatos = cursor.fetchone()[0]
    cursor.execute("SELECT COUNT(*) FROM noticias WHERE tipo_fonte LIKE '%Gossip%'")
    total_gossip = cursor.fetchone()[0]

    cursor.execute("SELECT setor, COUNT(*) as total FROM noticias GROUP BY setor")
    setores = {row["setor"]: row["total"] for row in cursor.fetchall()}
    
    cursor.execute("SELECT * FROM preferencias ORDER BY id DESC LIMIT 1")
    pref_row = cursor.fetchone()
    preferencias = dict(pref_row) if pref_row else {"email": "", "setor_alerta": "", "sensibilidade": "Alta"}

    conn.close()
    return noticias, total, {"positivo": pos, "negativo": neg, "neutro": max(total - pos - neg, 0), "fatos": total_fatos, "gossip": total_gossip}, setores, preferencias

def salvar_preferencias(email, setor_alerta, sensibilidade):
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    cursor.execute("INSERT INTO preferencias (email, setor_alerta, sensibilidade) VALUES (?, ?, ?)", (email, setor_alerta, sensibilidade))
    conn.commit()
    conn.close()
