import sqlite3
from database import DB_FILE

def verificar_e_disparar_alertas():
    conn = sqlite3.connect(DB_FILE)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    
    # Obter a última preferência guardada
    cursor.execute("SELECT * FROM preferencias ORDER BY id DESC LIMIT 1")
    pref = cursor.fetchone()
    
    if not pref:
        conn.close()
        return []
    
    email = pref["email"]
    setor_alvo = pref["setor_alerta"]
    
    # Buscar notícias recentes do setor alvo com forte sentimento (positivo ou negativo forte)
    cursor.execute("""
        SELECT * FROM noticias 
        WHERE (setor LIKE ? OR ticker LIKE ?) 
        AND (score_nlp >= 0.7 OR score_nlp <= -0.7)
        ORDER BY id DESC LIMIT 3
    """, (f"%{setor_alvo}%", f"%{setor_alvo}%"))
    
    artigos_criticos = [dict(row) for row in cursor.fetchall()]
    conn.close()
    
    alertas_gerados = []
    for art in artigos_criticos:
        msg = f"[ALERTA INSTITUCIONAL TRUFFLE FINDER] Destinatário: {email} | Ativo: {art['ticker']} | Sentimento Crítico: {art['sentimento']} ({art['score_nlp']}) - Título: {art['titulo']}"
        alertas_gerados.append(msg)
        
    return alertas_gerados
