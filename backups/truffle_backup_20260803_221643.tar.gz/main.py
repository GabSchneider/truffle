from fastapi import FastAPI, Form, Response
from fastapi.responses import HTMLResponse, RedirectResponse
import asyncio
from datetime import datetime
from database import init_db, buscar_dados_completos, salvar_preferencias
from nlp import processar_feeds
from reports import gerar_clipping_csv
from alerts import verificar_e_disparar_alertas

app = FastAPI(title="Truffle Finder - Terminal Institucional B3", version="19.0")

init_db()

async def background_rss_scheduler():
    while True:
        try:
            processar_feeds()
            # Verificar e simular disparo de alertas institucionais em background
            alertas = verificar_e_disparar_alertas()
            if alertas:
                for a in alertas:
                    print(a) # Registado nos logs do container Docker da VPS
        except Exception:
            pass
        await asyncio.sleep(900)

@app.on_event("startup")
async def startup_event():
    asyncio.create_task(background_rss_scheduler())

@app.get("/api/dados")
def api_dados(ticker: str = "TODOS", periodo: str = "TODOS", tipo_fonte: str = "TODOS"):
    processar_feeds()
    noticias, total, estatisticas, setores, preferencias = buscar_dados_completos(ticker, periodo, tipo_fonte)
    return {
        "status": "sucesso",
        "total": total,
        "estatisticas": estatisticas,
        "setores": setores,
        "preferencias": preferencias,
        "noticias": noticias
    }

@app.get("/api/exportar-clipping")
def exportar_clipping(ticker: str = "TODOS", tipo_fonte: str = "TODOS"):
    csv_data = gerar_clipping_csv(ticker, tipo_fonte)
    return Response(
        content=csv_data,
        media_type="text/csv",
        headers={"Content-Disposition": f"attachment; filename=clipping_truffle_finder_{ticker}.csv"}
    )

@app.post("/api/preferencias")
def post_preferencias(email: str = Form(...), setor_alerta: str = Form(...), sensibilidade: str = Form(...)):
    salvar_preferencias(email, setor_alerta, sensibilidade)
    return RedirectResponse(url="/?salvo=1", status_code=303)

@app.get("/", response_class=HTMLResponse)
def index():
    return """
    <!DOCTYPE html>
    <html lang="pt-BR">
    <head>
        <meta charset="UTF-8">
        <title>Truffle Finder - Terminal Institucional B3</title>
        <script src="https://cdn.tailwindcss.com"></script>
        <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    </head>
    <body class="bg-slate-950 text-slate-100 font-sans flex h-screen overflow-hidden">

        <aside class="w-72 bg-slate-900 border-r border-slate-800 flex flex-col justify-between p-6 shadow-2xl">
            <div>
                <div class="flex items-center gap-3 mb-8 pb-4 border-b border-slate-800">
                    <div class="bg-gradient-to-br from-blue-600/30 to-blue-900/40 p-2.5 rounded-2xl border border-blue-500/40 shadow flex items-center justify-center">
                        <span class="text-2xl">🐷</span>
                    </div>
                    <div>
                        <h1 class="text-base font-black tracking-wider text-white">TRUFFLE<span class="text-blue-500">FINDER</span></h1>
                        <p class="text-[10px] text-slate-400 uppercase tracking-widest font-semibold">Intelligence Terminal</p>
                    </div>
                </div>

                <div class="space-y-6">
                    <div>
                        <p class="text-[10px] font-bold uppercase tracking-widest text-slate-400 mb-3">Módulos Analíticos</p>
                        <nav class="space-y-1.5">
                            <button onclick="mudarModulo('dashboard')" id="btn-dashboard" class="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-xs font-semibold bg-blue-600 text-white transition text-left shadow">📊 Dashboard Executivo</button>
                            <button onclick="mudarModulo('fontes')" id="btn-fontes" class="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-xs font-semibold text-slate-400 hover:bg-slate-800 hover:text-white transition text-left">🔍 Classificação de Fontes</button>
                            <button onclick="mudarModulo('setores')" id="btn-setores" class="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-xs font-semibold text-slate-400 hover:bg-slate-800 hover:text-white transition text-left">🎯 Análise Setorial B3</button>
                            <button onclick="mudarModulo('preferencias')" id="btn-preferencias" class="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-xs font-semibold text-slate-400 hover:bg-slate-800 hover:text-white transition text-left">⚙️ Preferências & Alertas</button>
                        </nav>
                    </div>

                    <div>
                        <p class="text-[10px] font-bold uppercase tracking-widest text-slate-400 mb-3">Filtro Rápido Ibovespa</p>
                        <div class="grid grid-cols-2 gap-1.5">
                            <button onclick="filtrarTicker('TODOS')" class="px-2 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-xs font-mono text-slate-200 text-center transition ticker-btn shadow-inner" data-ticker="TODOS">🌐 TODOS</button>
                            <button onclick="filtrarTicker('PETR4')" class="px-2 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-xs font-mono text-slate-200 text-center transition ticker-btn" data-ticker="PETR4">⚡ PETR4</button>
                            <button onclick="filtrarTicker('VALE3')" class="px-2 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-xs font-mono text-slate-200 text-center transition ticker-btn" data-ticker="VALE3">⛏️ VALE3</button>
                            <button onclick="filtrarTicker('ITUB4')" class="px-2 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-xs font-mono text-slate-200 text-center transition ticker-btn" data-ticker="ITUB4">🏦 ITUB4</button>
                            <button onclick="filtrarTicker('MGLU3')" class="px-2 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-xs font-mono text-slate-200 text-center transition ticker-btn" data-ticker="MGLU3">🛒 MGLU3</button>
                        </div>
                    </div>
                </div>
            </div>

            <div class="pt-4 border-t border-slate-800 text-[11px] text-slate-500 flex justify-between items-center">
                <span>Sessão: Gestor B3</span>
                <span class="text-emerald-400 font-semibold animate-pulse">● Alertas Ativos</span>
            </div>
        </aside>

        <main class="flex-1 flex flex-col overflow-y-auto p-8">
            <header class="flex justify-between items-center mb-8 pb-4 border-b border-slate-800">
                <div>
                    <h2 id="titulo-topo" class="text-2xl font-bold text-slate-100">Dashboard Executivo & Termômetro de Rumores</h2>
                    <p class="text-xs text-slate-400 mt-1">Filtro: <span id="filtro-ativo-txt" class="text-blue-400 font-bold">TODOS</span> | Período: <span id="periodo-ativo-txt" class="text-emerald-400 font-bold">TODOS</span> | Tipo: <span id="tipo-ativo-txt" class="text-purple-400 font-bold">TODOS</span></p>
                </div>
                <div class="flex gap-3">
                    <button onclick="exportarClipping()" class="bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2 rounded-lg text-xs font-semibold transition shadow flex items-center gap-2">📥 Exportar Clipping (CSV)</button>
                    <button onclick="carregarDados(tickerAtual, periodoAtual, tipoFonteAtual)" class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-xs font-semibold transition shadow">🔄 Atualizar</button>
                </div>
            </header>

            <div id="modulo-dashboard" class="space-y-6">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div class="bg-slate-900 p-4 rounded-xl border border-slate-800 flex items-center gap-2 shadow">
                        <span class="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Período:</span>
                        <button onclick="filtrarPeriodo('TODOS')" class="px-2.5 py-1 rounded text-xs font-semibold bg-blue-600 text-white transition periodo-btn" data-periodo="TODOS">Geral</button>
                        <button onclick="filtrarPeriodo('HOJE')" class="px-2.5 py-1 rounded text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-300 transition periodo-btn" data-periodo="HOJE">Hoje</button>
                        <button onclick="filtrarPeriodo('24H')" class="px-2.5 py-1 rounded text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-300 transition periodo-btn" data-periodo="24H">24h</button>
                    </div>

                    <div class="bg-slate-900 p-4 rounded-xl border border-slate-800 flex items-center gap-2 shadow">
                        <span class="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Termômetro de Fontes:</span>
                        <button onclick="filtrarTipoFonte('TODOS')" class="px-2.5 py-1 rounded text-xs font-semibold bg-purple-600 text-white transition fonte-btn" data-fonte="TODOS">🌐 Todos</button>
                        <button onclick="filtrarTipoFonte('FATOS')" class="px-2.5 py-1 rounded text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-emerald-400 transition fonte-btn" data-fonte="FATOS">🟢 Fatos (Oficial)</button>
                        <button onclick="filtrarTipoFonte('GOSSIP')" class="px-2.5 py-1 rounded text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-rose-400 transition fonte-btn" data-fonte="GOSSIP">🟠 Gossip (Rumor)</button>
                    </div>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-4 gap-6">
                    <div class="bg-slate-900 p-6 rounded-xl border border-slate-800 shadow">
                        <h3 class="text-slate-400 text-xs font-bold uppercase tracking-wider">Total de Registros</h3>
                        <p id="stat-total" class="text-3xl font-bold text-white mt-2">-</p>
                    </div>
                    <div class="bg-slate-900 p-6 rounded-xl border border-slate-800 shadow">
                        <h3 class="text-slate-400 text-xs font-bold uppercase tracking-wider">Fatos Oficiais</h3>
                        <p id="stat-fatos" class="text-3xl font-bold text-emerald-400 mt-2">-</p>
                    </div>
                    <div class="bg-slate-900 p-6 rounded-xl border border-slate-800 shadow">
                        <h3 class="text-slate-400 text-xs font-bold uppercase tracking-wider">Rumores / Gossip</h3>
                        <p id="stat-gossip" class="text-3xl font-bold text-rose-400 mt-2">-</p>
                    </div>
                    <div class="bg-slate-900 p-6 rounded-xl border border-slate-800 shadow">
                        <h3 class="text-slate-400 text-xs font-bold uppercase tracking-wider">Ativo em Foco</h3>
                        <p id="stat-ativo-card" class="text-3xl font-bold text-blue-400 mt-2">TODOS</p>
                    </div>
                </div>

                <div class="bg-slate-900 p-6 rounded-xl border border-slate-800 shadow">
                    <h3 class="text-sm font-bold text-slate-200 mb-4">📈 Tese Analítica: Polaridade por NLP</h3>
                    <div style="height: 240px;"><canvas id="graficoNLP"></canvas></div>
                </div>

                <div class="bg-slate-900 p-6 rounded-xl border border-slate-800 shadow">
                    <h3 class="text-sm font-bold text-slate-200 mb-4">Stream Cruzado de Fatos e Rumores de Mercado</h3>
                    <div class="overflow-x-auto">
                        <table class="w-full text-left border-collapse">
                            <thead>
                                <tr class="border-b border-slate-800 text-slate-400 text-[11px] uppercase tracking-wider">
                                    <th class="p-3">Data</th>
                                    <th class="p-3">Ticker / Subsetor</th>
                                    <th class="p-3">Tipo de Fonte</th>
                                    <th class="p-3">Título & Link</th>
                                    <th class="p-3">Origem</th>
                                    <th class="p-3">Sentimento (NLP)</th>
                                </tr>
                            </thead>
                            <tbody id="tabela-corpo" class="divide-y divide-slate-800/60 text-sm">
                                <tr><td colspan="6" class="p-6 text-center text-slate-500">A carregar registos...</td></tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <div id="modulo-fontes" class="hidden space-y-6">
                <div class="bg-slate-900 rounded-xl border border-slate-800 p-6">
                    <h3 class="text-lg font-bold text-slate-200 mb-4">🔍 Ponderação de Fatos vs. Gossip</h3>
                    <p class="text-xs text-slate-400 mb-6">O Truffle Finder cruza dados oficiais com ondas de especulação (*gossip*).</p>
                </div>
            </div>

            <div id="modulo-setores" class="hidden space-y-6">
                <div class="bg-slate-900 rounded-xl border border-slate-800 p-6">
                    <h3 class="text-lg font-bold text-slate-200 mb-4">🎯 Macrosetores e Subsetores B3</h3>
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-4" id="grid-setores-card"></div>
                </div>
            </div>

            <div id="modulo-preferencias" class="hidden space-y-6">
                <div class="bg-slate-900 rounded-xl border border-slate-800 p-6 max-w-xl">
                    <h3 class="text-lg font-bold text-slate-200 mb-4">⚙️ Configurações de Alertas Automáticos</h3>
                    <form action="/api/preferencias" method="POST" class="space-y-4">
                        <div>
                            <label class="block text-xs font-semibold text-slate-400 mb-1">E-mail para Alertas</label>
                            <input type="email" name="email" id="input-email" required class="w-full bg-slate-950 border border-slate-800 rounded px-3 py-2 text-xs text-slate-200">
                        </div>
                        <div>
                            <label class="block text-xs font-semibold text-slate-400 mb-1">Setor ou Ticker Alvo</label>
                            <input type="text" name="setor_alerta" id="input-setor" required class="w-full bg-slate-950 border border-slate-800 rounded px-3 py-2 text-xs text-slate-200">
                        </div>
                        <div>
                            <label class="block text-xs font-semibold text-slate-400 mb-1">Sensibilidade de Volatilidade</label>
                            <select name="sensibilidade" id="select-sens" class="w-full bg-slate-950 border border-slate-800 rounded px-3 py-2 text-xs text-slate-200">
                                <option value="Alta">Alta (Score >= |0.7|)</option>
                                <option value="Moderada">Moderada</option>
                            </select>
                        </div>
                        <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded text-xs font-semibold transition w-full">Guardar Preferências no Sistema</button>
                    </form>
                </div>
            </div>
        </main>

        <script>
            let tickerAtual = 'TODOS';
            let periodoAtual = 'TODOS';
            let tipoFonteAtual = 'TODOS';
            let chartInstancia = null;

            function mudarModulo(mod) {
                ['dashboard', 'fontes', 'setores', 'preferencias'].forEach(m => {
                    document.getElementById(`modulo-${m}`).classList.add('hidden');
                    document.getElementById(`btn-${m}`).className = "w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-xs font-semibold text-slate-400 hover:bg-slate-800 hover:text-white transition text-left";
                });
                document.getElementById(`modulo-${mod}`).classList.remove('hidden');
                document.getElementById(`btn-${mod}`).className = "w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-xs font-semibold bg-blue-600 text-white transition text-left shadow";
            }

            async function carregarDados(ticker = 'TODOS', periodo = 'TODOS', tipoFonte = 'TODOS') {
                tickerAtual = ticker;
                periodoAtual = periodo;
                tipoFonteAtual = tipoFonte;
                
                document.getElementById('filtro-ativo-txt').innerText = ticker;
                document.getElementById('periodo-ativo-txt').innerText = periodo;
                document.getElementById('tipo-ativo-txt').innerText = tipoFonte;
                document.getElementById('stat-ativo-card').innerText = ticker;
                
                document.querySelectorAll('.ticker-btn').forEach(btn => {
                    if(btn.getAttribute('data-ticker') === ticker) {
                        btn.className = "px-2 py-1.5 rounded bg-blue-600 text-white text-xs font-mono text-center transition ticker-btn shadow";
                    } else {
                        btn.className = "px-2 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-xs font-mono text-slate-200 text-center transition ticker-btn";
                    }
                });

                document.querySelectorAll('.periodo-btn').forEach(btn => {
                    if(btn.getAttribute('data-periodo') === periodo) {
                        btn.className = "px-2.5 py-1 rounded text-xs font-semibold bg-blue-600 text-white transition periodo-btn shadow";
                    } else {
                        btn.className = "px-2.5 py-1 rounded text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-300 transition periodo-btn";
                    }
                });

                document.querySelectorAll('.fonte-btn').forEach(btn => {
                    if(btn.getAttribute('data-fonte') === tipoFonte) {
                        btn.className = "px-2.5 py-1 rounded text-xs font-semibold bg-purple-600 text-white transition fonte-btn shadow";
                    } else {
                        btn.className = "px-2.5 py-1 rounded text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-300 transition fonte-btn";
                    }
                });

                try {
                    const res = await fetch(`/api/dados?ticker=${ticker}&periodo=${periodo}&tipo_fonte=${tipoFonte}`);
                    const data = await res.json();
                    
                    document.getElementById('stat-total').innerText = data.total;
                    document.getElementById('stat-fatos').innerText = data.estatisticas.fatos;
                    document.getElementById('stat-gossip').innerText = data.estatisticas.gossip;
                    
                    if(data.preferencias) {
                        document.getElementById('input-email').value = data.preferencias.email || '';
                    }

                    const gridSetores = document.getElementById('grid-setores-card');
                    gridSetores.innerHTML = '';
                    for (const [setor, qtd] of Object.entries(data.setores)) {
                        gridSetores.innerHTML += `
                            <div class="bg-slate-950 p-4 rounded-lg border border-slate-800">
                                <h4 class="font-bold text-blue-400 text-sm">${setor}</h4>
                                <p class="text-xs text-slate-400 mt-1">${qtd} artigos indexados</p>
                            </div>
                        `;
                    }
                    
                    const tbody = document.getElementById('tabela-corpo');
                    tbody.innerHTML = '';
                    
                    if(data.noticias.length === 0) {
                        tbody.innerHTML = '<tr><td colspan="6" class="p-6 text-center text-slate-500">Nenhum registo encontrado com estes filtros cruzados.</td></tr>';
                        return;
                    }
                    
                    data.noticias.forEach(n => {
                        let badgeSentimento = 'bg-slate-800 text-slate-300 border-slate-700';
                        if(n.sentimento === 'Positivo') badgeSentimento = 'bg-emerald-950 text-emerald-400 border-emerald-800';
                        if(n.sentimento === 'Negativo') badgeSentimento = 'bg-rose-950 text-rose-400 border-rose-800';

                        let badgeFonte = n.tipo_fonte.includes('Fato') ? 'text-emerald-400 bg-emerald-950/40 border-emerald-900' : 'text-rose-400 bg-rose-950/40 border-rose-900';
                        
                        const tr = document.createElement('tr');
                        tr.className = 'hover:bg-slate-800/40 transition';
                        tr.innerHTML = `
                            <td class="p-3 text-slate-400 text-xs whitespace-nowrap">${n.data}</td>
                            <td class="p-3"><span class="font-mono font-bold text-blue-400">${n.ticker}</span><br><span class="text-[10px] text-slate-400">${n.subsetor || ''}</span></td>
                            <td class="p-3"><span class="px-2 py-0.5 rounded text-[11px] font-semibold border ${badgeFonte}">${n.tipo_fonte}</span></td>
                            <td class="p-3"><a href="${n.link}" target="_blank" class="hover:text-blue-400 transition text-slate-100">${n.titulo}</a></td>
                            <td class="p-3 text-xs text-slate-400">${n.fonte}</td>
                            <td class="p-3"><span class="px-2.5 py-1 rounded-full text-xs font-semibold border ${badgeSentimento}">${n.sentimento} (${n.score_nlp})</span></td>
                        `;
                        tbody.appendChild(tr);
                    });

                    renderizarGrafico(data.estatisticas);
                } catch (err) {
                    console.error("Erro ao carregar dados:", err);
                }
            }

            function filtrarTicker(t) { carregarDados(t, periodoAtual, tipoFonteAtual); }
            function filtrarPeriodo(p) { carregarDados(tickerAtual, p, tipoFonteAtual); }
            function filtrarTipoFonte(f) { carregarDados(tickerAtual, periodoAtual, f); }

            function exportarClipping() {
                window.location.href = `/api/exportar-clipping?ticker=${tickerAtual}&tipo_fonte=${tipoFonteAtual}`;
            }

            function renderizarGrafico(estat) {
                const ctx = document.getElementById('graficoNLP').getContext('2d');
                if(chartInstancia) chartInstancia.destroy();
                
                chartInstancia = new Chart(ctx, {
                    type: 'bar',
                    data: {
                        labels: ['Positivo (Bullish)', 'Neutro', 'Negativo (Bearish)'],
                        datasets: [{
                            data: [estat.positivo, estat.neutro, estat.negativo],
                            backgroundColor: ['#10B981', '#F59E0B', '#EF4444'],
                            borderRadius: 6
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: { legend: { display: false } },
                        scales: {
                            x: { grid: { display: false }, ticks: { color: '#94A3B8' } },
                            y: { grid: { color: '#1E293B' }, ticks: { color: '#94A3B8' } }
                        }
                    }
                });
            }

            carregarDados('TODOS', 'TODOS', 'TODOS');
        </script>
    </body>
    </html>
    """
