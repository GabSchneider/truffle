import feedparser
from datetime import datetime, timedelta
import random
from database import salvar_noticia

# Mapeamento completo das principais empresas e tickers do Índice Ibovespa (B3)
IBOV_MAPA = {
    "PETR4": {"nome": "Petrobras", "setor": "Petróleo, Gás e Biocombustíveis", "subsetor": "Exploração e Produção"},
    "VALE3": {"nome": "Vale", "setor": "Materiais Básicos", "subsetor": "Mineração"},
    "ITUB4": {"nome": "Itaú Unibanco", "setor": "Financeiro", "subsetor": "Bancos Comerciais"},
    "BBDC4": {"nome": "Bradesco", "setor": "Financeiro", "subsetor": "Bancos Comerciais"},
    "BBAS3": {"nome": "Banco do Brasil", "setor": "Financeiro", "subsetor": "Bancos Comerciais"},
    "SANB11": {"nome": "Santander Brasil", "setor": "Financeiro", "subsetor": "Bancos Comerciais"},
    "B3SA3": {"nome": "B3", "setor": "Financeiro", "subsetor": "Serviços Financeiros Diversos"},
    "ABEV3": {"nome": "Ambev", "setor": "Consumo Não Cíclico", "subsetor": "Bebidas e Cervejas"},
    "JBSS3": {"nome": "JBS", "setor": "Consumo Não Cíclico", "subsetor": "Carnes e Derivados"},
    "MGLU3": {"nome": "Magazine Luiza", "setor": "Consumo Cíclico", "subsetor": "Varejo Digital"},
    "LREN3": {"nome": "Lojas Renner", "setor": "Consumo Cíclico", "subsetor": "Tecidos, Vestuário e Calçados"},
    "WEGE3": {"nome": "Weg", "setor": "Bens Industriais", "subsetor": "Máquinas e Equipamentos"},
    "RENT3": {"nome": "Localiza", "setor": "Consumo Cíclico", "subsetor": "Aluguel de Carros"},
    "SUZB3": {"nome": "Suzano", "setor": "Materiais Básicos", "subsetor": "Madeira e Celulose"},
    "CSNA3": {"nome": "CSN", "setor": "Materiais Básicos", "subsetor": "Siderurgia e Metalurgia"},
    "GGBR4": {"nome": "Gerdau", "setor": "Materiais Básicos", "subsetor": "Siderurgia e Metalurgia"},
    "ELET3": {"nome": "Eletrobras", "setor": "Utilidade Pública", "subsetor": "Energia Elétrica"},
    "CPLE6": {"nome": "Copel", "setor": "Utilidade Pública", "subsetor": "Energia Elétrica"},
    "CMIG4": {"nome": "Cemig", "setor": "Utilidade Pública", "subsetor": "Energia Elétrica"},
    "TIMS3": {"nome": "TIM", "setor": "Telecomunicações", "subsetor": "Telecomunicações"},
    "VIVT3": {"nome": "Telefônica Brasil", "setor": "Telecomunicações", "subsetor": "Telecomunicações"}
}

RSS_FEEDS = [
    {"name": "Valor Econômico", "url": "https://valor.globo.com/rss/"},
    {"name": "InfoMoney", "url": "https://www.infomoney.com.br/feed/"}
]

def analisar_nlp(texto: str):
    t_lower = texto.lower()
    positivas = ["alta", "lucro", "crescimento", "disparou", "positivo", "superou", "recorde", "expansão", "dividendo", "valorização", "avanço"]
    negativas = ["queda", "prejuízo", "crise", "despencou", "negativo", "investigação", "falência", "corte", "processo", "retração"]
    
    score = 0.0
    for p in positivas:
        if p in t_lower: score += 0.25
    for n in negativas:
        if n in t_lower: score -= 0.25
        
    score = max(min(score, 1.0), -1.0)
    if score > 0.05: label = "Positivo"
    elif score < -0.05: label = "Negativo"
    else: label = "Neutro"
    return label, round(score, 2)

def gerar_noticias_simuladas_mercado():
    """Gera massa de dados contínua e diversificada para todas as empresas do Ibovespa"""
    fontes_fatos = ["Valor Econômico", "InfoMoney", "Exame", "Broadcast CVM/B3"]
    fontes_gossip = ["X / Fórum Corporativo", "Reddit / InvestidoresBR", "Blog de Bastidores B3", "Canal de Rumores M&A"]
    
    templates_fatos = [
        ("Fato Relevante: {empresa} ({ticker}) reporta resultado trimestral acima das projeções do mercado.", "Positivo", 0.80),
        ("Conselho de Administração da {empresa} ({ticker}) aprova distribuição complementar de proventos.", "Positivo", 0.70),
        ("Setor de {setor} enfrenta nova diretriz regulatória, impactando as operações de {ticker}.", "Negativo", -0.50),
        ("{empresa} ({ticker}) anuncia reestruturação estratégica voltada para eficiência operacional.", "Neutro", 0.10)
    ]
    
    templates_gossip = [
        ("Boato forte no pregão: {empresa} ({ticker}) estuda operação corporativa surpresa.", "Positivo", 0.60),
        ("Especulação de bastidor aponta movimentações atípicas nos papéis de {empresa} ({ticker}).", "Negativo", -0.65),
        ("Fontes de mercado comentam sobre possível aquisição de ativos estratégicos por parte de {ticker}.", "Neutro", 0.00),
        ("Rumor de forte volatilidade institucional para {empresa} ({ticker}) repercute nas redes sociais.", "Negativo", -0.40)
    ]

    agora = datetime.now()
    
    # Seleciona aleatoriamente um subconjunto do Ibovespa a cada ciclo para alimentar o fluxo de forma realista
    tickers_amostra = random.sample(list(IBOV_MAPA.keys()), k=8)
    
    for ticker in tickers_amostra:
        info = IBOV_MAPA[ticker]
        
        # Ingerir Fato
        t_fato = random.choice(templates_fatos)
        titulo_fato = t_fato[0].format(empresa=info["nome"], ticker=ticker, setor=info["setor"])
        salvar_noticia({
            "titulo": f"{titulo_fato} [{agora.strftime('%H:%M:%S')}]",
            "fonte": random.choice(fontes_fatos),
            "tipo_fonte": "Fato (Confiável)",
            "data": agora.strftime("%d/%m %H:%M"),
            "link": "https://valor.globo.com",
            "ticker": ticker,
            "setor": info["setor"],
            "subsetor": info["subsetor"],
            "sentimento": t_fato[1],
            "score_nlp": t_fato[2]
        })
        
        # Ingerir Gossip / Rumor
        t_gossip = random.choice(templates_gossip)
        titulo_gossip = t_gossip[0].format(empresa=info["nome"], ticker=ticker)
        salvar_noticia({
            "titulo": f"{titulo_gossip} [{agora.strftime('%H:%M:%S')}]",
            "fonte": random.choice(fontes_gossip),
            "tipo_fonte": "Gossip (Rumor)",
            "data": agora.strftime("%d/%m %H:%M"),
            "link": "https://twitter.com",
            "ticker": ticker,
            "setor": info["setor"],
            "subsetor": info["subsetor"],
            "sentimento": t_gossip[1],
            "score_nlp": t_gossip[2]
        })

def processar_feeds():
    """Varre RSS reais e injeta a massa dinâmica simulada cobrindo todo o Ibovespa"""
    for fonte in RSS_FEEDS:
        try:
            feed = feedparser.parse(fonte["url"])
            for entry in feed.entries[:10]:
                titulo = entry.get("title", "")
                link = entry.get("link", "")
                data_pub = entry.get("published", str(datetime.now()))[:16]
                
                ticker_enq = "IBOV / GERAL"
                setor_enq = "Macroeconomia"
                subsetor_enq = "Geral"
                for t, info in IBOV_MAPA.items():
                    if t.lower() in titulo.lower() or info["nome"].lower() in titulo.lower():
                        ticker_enq = t
                        setor_enq = info["setor"]
                        subsetor_enq = info["subsetor"]
                        break
                
                sentimento, score = analisar_nlp(titulo)
                salvar_noticia({
                    "titulo": titulo,
                    "fonte": fonte["name"],
                    "tipo_fonte": "Fato (Confiável)",
                    "data": data_pub,
                    "link": link,
                    "ticker": ticker_enq,
                    "setor": setor_enq,
                    "subsetor": subsetor_enq,
                    "sentimento": sentimento,
                    "score_nlp": score
                })
        except Exception:
            continue
            
    gerar_noticias_simuladas_mercado()
