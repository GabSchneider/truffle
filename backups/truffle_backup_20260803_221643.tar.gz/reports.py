import csv
import io
from database import sqlite3, DB_FILE

def gerar_clipping_csv(ticker="TODOS", tipo_fonte="TODOS"):
    conn = sqlite3.connect(DB_FILE)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    
    query = "SELECT data, ticker, setor, subsetor, tipo_fonte, titulo, fonte, sentimento, score_nlp FROM noticias WHERE 1=1"
    params = []
    
    if ticker and ticker != "TODOS":
        query += " AND ticker = ?"
        params.append(ticker)
        
    if tipo_fonte and tipo_fonte != "TODOS":
        if tipo_fonte == "FATOS":
            query += " AND tipo_fonte LIKE ?"
            params.append("%Fato%")
        elif tipo_fonte == "GOSSIP":
            query += " AND tipo_fonte LIKE ?"
            params.append("%Gossip%")
            
    query += " ORDER BY id DESC"
    
    cursor.execute(query, params)
    rows = cursor.fetchall()
    conn.close()
    
    output = io.StringIO()
    writer = csv.writer(output)
    # Cabeçalho do Clipping Institucional
    writer.writerow(["Data", "Ticker", "Setor", "Subsetor", "Tipo de Fonte", "Título", "Origem", "Sentimento", "Score NLP"])
    
    for row in rows:
        writer.writerow([row["data"], row["ticker"], row["setor"], row["subsetor"], row["tipo_fonte"], row["titulo"], row["fonte"], row["sentimento"], row["score_nlp"]])
        
    output.seek(0)
    return output.getvalue()
