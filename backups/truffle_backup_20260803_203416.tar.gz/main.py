from fastapi import FastAPI, HTTPException
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
import feedparser
from datetime import datetime
import sqlite3

app = FastAPI(title="Truffle Finder - Terminal Institucional B3", version="8.0")

# Montar pasta estática para imagens e assets
app.mount("/static", StaticFiles(directory="static"), name="static")

DB_FILE = "truffle_history.db"

def init_db():
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS noticias (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            titulo TEXT UNIQUE,
            fonte TEXT,
            tipo_fonte TEXT,
            data TEXT,
            link TEXT,
            ticker TEXT,
            setor TEXT,
            sentimento TEXT,
            score_nlp REAL,
            criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    conn.commit()
    conn.close()

init_db()

IBOV_MAPA = {
    "PETR4": {"nome": "Petrobras PN", "setor": "Petróleo, Gás e Biocombustíveis"},
    "VALE3": {"nome": "Vale", "setor": "Mineração / Materiais Básicos"},
    "ITUB4": {"nome": "Itaú Unibanco", "setor": "Financeiro"},
    "BBDC4": {"nome": "Bradesco", "setor": "Financeiro"},
    "ABEV3": {"nome": "Ambev", "setor": "Consumo Não Cíclico"},
    "MGLU3": {"nome": "Magazine Luiza", "setor": "Consumo Cíclico"},
    "WEGE3": {"nome": "Weg", "setor": "Bens Industriais"},
    "SUZB3": {"nome": "Suzano", "setor": "Papel e Celulose"}
}

RSS_FEEDS = [
    {"name": "Valor Econômico", "url": "https://valor.globo.com/rss/", "tipo": "Confiável (Institucional)"},
    {"name": "InfoMoney", "url": "https://www.infomoney.com.br/feed/", "tipo": "Confiável (Mercado)"}
]

def analisar_nlp(texto: str):
    t_lower = texto.lower()
    positivas = ["alta", "lucro", "crescimento", "disparou", "positivo", "superou", "recorde", "expansão", "dividendo", "valorização", "avanço"]
    negativas = ["queda", "prejuízo", "crise", "despencou", "negativo", "investigação", "falência", "corte", "processo", "retração"]
    
    score = 0.0
    for p in positivas:
        if p in t_lower: score += 0.25
    for n in negativas:
        if n in t_lower: score -= 0.25
        
    score = max(min(score, 1.0), -1.0)
    
    if score > 0.05: label = "Positivo"
    elif score < -0.05: label = "Negativo"
    else: label = "Neutro"
    
    return label, round(score, 2)

def sincronizar_feeds():
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    
    for fonte in RSS_FEEDS:
        try:
            feed = feedparser.parse(fonte["url"])
            for entry in feed.entries[:25]:
                titulo = entry.get("title", "")
                link = entry.get("link", "")
                data_pub = entry.get("published", str(datetime.now()))[:16]
                
                ticker_enq = "IBOV / MERCADO"
                setor_enq = "Macroeconomia"
                
                for t, info in IBOV_MAPA.items():
                    if t.lower() in titulo.lower() or info["nome"].lower() in titulo.lower():
                        ticker_enq = t
                        setor_enq = info["setor"]
                        break
                
                sentimento, score = analisar_nlp(titulo)
                
                try:
                    cursor.execute('''
                        INSERT INTO noticias (titulo, fonte, tipo_fonte, data, link, ticker, setor, sentimento, score_nlp)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ''', (titulo, fonte["name"], fonte["tipo"], data_pub, link, ticker_enq, setor_enq, sentimento, score))
                except sqlite3.IntegrityError:
                    pass
        except Exception:
            continue
            
    conn.commit()
    conn.close()

@app.get("/api/dados")
def api_dados(ticker: str = "TODOS"):
    sincronizar_feeds()
    conn = sqlite3.connect(DB_FILE)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    
    if ticker and ticker != "TODOS":
        cursor.execute("SELECT * FROM noticias WHERE ticker = ? ORDER BY id DESC LIMIT 50", (ticker,))
    else:
        cursor.execute("SELECT * FROM noticias ORDER BY id DESC LIMIT 50")
        
    rows = cursor.fetchall()
    noticias = [dict(r) for r in rows]
    
    cursor.execute("SELECT COUNT(*) FROM noticias")
    total = cursor.fetchone()[0]
    
    cursor.execute("SELECT COUNT(*) FROM noticias WHERE sentimento='Positivo'")
    pos = cursor.fetchone()[0]
    
    cursor.execute("SELECT COUNT(*) FROM noticias WHERE sentimento='Negativo'")
    neg = cursor.fetchone()[0]
    
    conn.close()
    
    return {
        "status": "sucesso",
        "total_noticias": total,
        "estatisticas": {"positivo": pos, "negativo": neg, "neutro": max(total - pos - neg, 0)},
        "noticias": noticias
    }

@app.get("/", response_class=HTMLResponse)
def index():
    return """
    <!DOCTYPE html>
    <html lang="pt-BR">
    <head>
        <meta charset="UTF-8">
        <title>Truffle Finder - Terminal Institucional B3</title>
        <script src="https://cdn.tailwindcss.com"></script>
        <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    </head>
    <body class="bg-slate-950 text-slate-100 font-sans flex h-screen overflow-hidden">

        <aside class="w-72 bg-slate-900 border-r border-slate-800 flex flex-col justify-between p-6">
            <div>
                <div class="flex items-center gap-3 mb-8 pb-4 border-b border-slate-800">
                    <div class="bg-slate-950 p-2 rounded-xl border border-slate-800 flex items-center justify-center shadow">
                        <img src="/static/logo.png" alt="Truffle Finder Logo" class="w-10 h-10 object-contain" onerror="this.style.display='none'; document.getElementById('fallback-logo').style.display='flex';">
                        <div id="fallback-logo" style="display:none;" class="w-10 h-10 items-center justify-center text-xl">🐷</div>
                    </div>
                    <div>
                        <h1 class="text-base font-black tracking-wider text-white">TRUFFLE<span class="text-blue-500">FINDER</span></h1>
                        <p class="text-[10px] text-slate-400 uppercase tracking-widest font-semibold">Intelligence Terminal</p>
                    </div>
                </div>

                <div class="space-y-6">
                    <div>
                        <p class="text-[10px] font-bold uppercase tracking-widest text-slate-400 mb-3">Módulos Analíticos</p>
                        <nav class="space-y-1.5">
                            <button onclick="mudarModulo('dashboard')" id="btn-mod-dashboard" class="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-xs font-semibold bg-blue-600 text-white transition text-left">📊 Dashboard & Tese NLP</button>
                            <button onclick="mudarModulo('fontes')" id="btn-mod-fontes" class="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-xs font-semibold text-slate-400 hover:bg-slate-800 hover:text-slate-200 transition text-left">🔍 Classificação de Fontes</button>
                            <button onclick="mudarModulo('setorial')" id="btn-mod-setorial" class="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-xs font-semibold text-slate-400 hover:bg-slate-800 hover:text-slate-200 transition text-left">🎯 Análise Setorial B3</button>
                            <button onclick="mudarModulo('preferencias')" id="btn-mod-preferencias" class="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-xs font-semibold text-slate-400 hover:bg-slate-800 hover:text-slate-200 transition text-left">⚙️ Preferências & Alertas</button>
                        </nav>
                    </div>

                    <div>
                        <p class="text-[10px] font-bold uppercase tracking-widest text-slate-400 mb-3">Filtro Rápido Ibovespa</p>
                        <div class="grid grid-cols-2 gap-1.5">
                            <button onclick="filtrarTicker('TODOS')" class="px-2 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-xs font-mono text-slate-200 text-center transition ticker-btn" data-ticker="TODOS">🌐 TODOS</button>
                            <button onclick="filtrarTicker('PETR4')" class="px-2 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-xs font-mono text-slate-200 text-center transition ticker-btn" data-ticker="PETR4">⚡ PETR4</button>
                            <button onclick="filtrarTicker('VALE3')" class="px-2 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-xs font-mono text-slate-200 text-center transition ticker-btn" data-ticker="VALE3">⛏️ VALE3</button>
                            <button onclick="filtrarTicker('ITUB4')" class="px-2 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-xs font-mono text-slate-200 text-center transition ticker-btn" data-ticker="ITUB4">🏦 ITUB4</button>
                            <button onclick="filtrarTicker('BBDC4')" class="px-2 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-xs font-mono text-slate-200 text-center transition ticker-btn" data-ticker="BBDC4">💳 BBDC4</button>
                            <button onclick="filtrarTicker('ABEV3')" class="px-2 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-xs font-mono text-slate-200 text-center transition ticker-btn" data-ticker="ABEV3">🍺 ABEV3</button>
                        </div>
                    </div>
                </div>
            </div>

            <div class="pt-4 border-t border-slate-800 text-[11px] text-slate-500 flex justify-between items-center">
                <span>Sessão: Gestor B3</span>
                <span class="text-emerald-400 font-semibold">● Online</span>
            </div>
        </aside>

        <main class="flex-1 flex flex-col overflow-y-auto p-8">
            <header class="flex justify-between items-center mb-8 pb-4 border-b border-slate-800">
                <div>
                    <h2 id="titulo-pagina" class="text-2xl font-bold text-slate-100">Dashboard Executivo & Tese NLP</h2>
                    <p class="text-xs text-slate-400 mt-1">Cruzamento de sentimento de mercado com o índice Ibovespa em tempo real.</p>
                </div>
                <button onclick="carregarDados(tickerAtual)" class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-xs font-semibold transition shadow">🔄 Atualizar Terminal</button>
            </header>

            <div id="conteudo-modulo" class="space-y-6">
                <div id="mod-dashboard" class="space-y-6">
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <div class="bg-slate-900 p-6 rounded-xl border border-slate-800 shadow">
                            <h3 class="text-slate-400 text-xs font-bold uppercase tracking-wider">Total de Artigos Processados</h3>
                            <p id="stat-total" class="text-3xl font-bold text-white mt-2">-</p>
                        </div>
                        <div class="bg-slate-900 p-6 rounded-xl border border-slate-800 shadow">
                            <h3 class="text-slate-400 text-xs font-bold uppercase tracking-wider">Viés Majoritário (NLP)</h3>
                            <p id="stat-vies" class="text-3xl font-bold text-emerald-400 mt-2">Bullish (Positivo)</p>
                        </div>
                        <div class="bg-slate-900 p-6 rounded-xl border border-slate-800 shadow">
                            <h3 class="text-slate-400 text-xs font-bold uppercase tracking-wider">Filtro Ativo Atual</h3>
                            <p id="stat-filtro" class="text-3xl font-bold text-blue-400 mt-2">TODOS</p>
                        </div>
                    </div>

                    <div class="bg-slate-900 p-6 rounded-xl border border-slate-800 shadow">
                        <h3 class="text-sm font-bold text-slate-200 mb-4">📈 Tese Analítica: Índice de Sentimento vs. Tendência Ibovespa</h3>
                        <div style="height: 280px;"><canvas id="graficoTese"></canvas></div>
                    </div>

                    <div class="bg-slate-900 rounded-xl border border-slate-800 p-6 shadow">
                        <h3 class="text-sm font-bold text-slate-200 mb-4">Stream de Notícias & Insights Lexicais</h3>
                        <div class="overflow-x-auto">
                            <table class="w-full text-left border-collapse">
                                <thead>
                                    <tr class="border-b border-slate-800 text-slate-400 text-[11px] uppercase tracking-wider">
                                        <th class="p-3">Data</th>
                                        <th class="p-3">Ticker</th>
                                        <th class="p-3">Setor</th>
                                        <th class="p-3">Título & Link</th>
                                        <th class="p-3">Fonte</th>
                                        <th class="p-3">Sentimento (NLP)</th>
                                    </tr>
                                </thead>
                                <tbody id="tabela-noticias" class="divide-y divide-slate-800/60 text-sm">
                                    <tr><td colspan="6" class="p-6 text-center text-slate-500">A carregar dados...</td></tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <div id="mod-fontes" class="hidden space-y-6">
                    <div class="bg-slate-900 rounded-xl border border-slate-800 p-6">
                        <h3 class="text-lg font-bold text-slate-200 mb-4">🔍 Credibilidade e Ponderação de Fontes</h3>
                        <p class="text-xs text-slate-400 mb-6">O Truffle Finder categoriza rigorosamente os canais de informação para filtrar ruído de mercado.</p>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div class="bg-slate-950 p-5 rounded-lg border border-slate-800">
                                <h4 class="text-sm font-bold text-emerald-400 mb-2">🟢 Fontes Confiáveis / Oficiais</h4>
                                <p class="text-xs text-slate-400 mb-3">Valor Econômico, InfoMoney, Broadcast e comunicados oficiais.</p>
                            </div>
                            <div class="bg-slate-950 p-5 rounded-lg border border-slate-800">
                                <h4 class="text-sm font-bold text-rose-400 mb-2">🟠 Mídias Alternativas / Rumores</h4>
                                <p class="text-xs text-slate-400 mb-3">Redes sociais e blogs especulativos filtrados com menor ponderação.</p>
                            </div>
                        </div>
                    </div>
                </div>

                <div id="mod-setorial" class="hidden space-y-6">
                    <div class="bg-slate-900 rounded-xl border border-slate-800 p-6">
                        <h3 class="text-lg font-bold text-slate-200 mb-4">🎯 Macrosetores da B3 Monitorados</h3>
                        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <div class="bg-slate-950 p-4 rounded-lg border border-slate-800"><h4 class="font-bold text-blue-400 text-sm">Petróleo e Gás</h4></div>
                            <div class="bg-slate-950 p-4 rounded-lg border border-slate-800"><h4 class="font-bold text-blue-400 text-sm">Financeiro & Bancos</h4></div>
                            <div class="bg-slate-950 p-4 rounded-lg border border-slate-800"><h4 class="font-bold text-blue-400 text-sm">Materiais Básicos</h4></div>
                        </div>
                    </div>
                </div>

                <div id="mod-preferencias" class="hidden space-y-6">
                    <div class="bg-slate-900 rounded-xl border border-slate-800 p-6 max-w-xl">
                        <h3 class="text-lg font-bold text-slate-200 mb-4">⚙️ Configurações de Alertas</h3>
                        <div class="space-y-4">
                            <div><label class="block text-xs font-semibold text-slate-400 mb-1">E-mail para Alertas</label><input type="email" value="gestor@trufflefinder.com.br" class="w-full bg-slate-950 border border-slate-800 rounded px-3 py-2 text-xs text-slate-200"></div>
                            <button onclick="alert('Guardado!')" class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded text-xs font-semibold transition">Guardar</button>
                        </div>
                    </div>
                </div>
            </div>
        </main>

        <script>
            let tickerAtual = 'TODOS';
            let meuGrafico = null;

            function mudarModulo(mod) {
                ['dashboard', 'fontes', 'setorial', 'preferencias'].forEach(m => {
                    document.getElementById(`mod-${m}`).classList.add('hidden');
                    document.getElementById(`btn-mod-${m}`).className = "w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-xs font-semibold text-slate-400 hover:bg-slate-800 hover:text-slate-200 transition text-left";
                });
                document.getElementById(`mod-${mod}`).classList.remove('hidden');
                document.getElementById(`btn-mod-${mod}`).className = "w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-xs font-semibold bg-blue-600 text-white transition text-left";
            }

            async function carregarDados(ticker = 'TODOS') {
                tickerAtual = ticker;
                document.getElementById('stat-filtro').innerText = ticker;
                try {
                    const res = await fetch(`/api/dados?ticker=${ticker}`);
                    const data = await res.json();
                    document.getElementById('stat-total').innerText = data.total_noticias;
                    const tbody = document.getElementById('tabela-noticias');
                    tbody.innerHTML = '';
                    data.noticias.forEach(n => {
                        let badge = 'bg-slate-800 text-slate-300 border-slate-700';
                        if(n.sentimento === 'Positivo') badge = 'bg-emerald-950 text-emerald-400 border-emerald-800';
                        if(n.sentimento === 'Negativo') badge = 'bg-rose-950 text-rose-400 border-rose-800';
                        const tr = document.createElement('tr');
                        tr.className = 'hover:bg-slate-800/40 transition';
                        tr.innerHTML = `
                            <td class="p-3 text-slate-400 text-xs whitespace-nowrap">${n.data}</td>
                            <td class="p-3 font-mono font-bold text-blue-400">${n.ticker}</td>
                            <td class="p-3 text-slate-300 text-xs">${n.setor}</td>
                            <td class="p-3"><a href="${n.link}" target="_blank" class="hover:text-blue-400 transition text-slate-100">${n.titulo}</a></td>
                            <td class="p-3 text-xs text-slate-400">${n.fonte}</td>
                            <td class="p-3"><span class="px-2.5 py-1 rounded-full text-xs font-semibold border ${badge}">${n.sentimento} (${n.score_nlp})</span></td>
                        `;
                        tbody.appendChild(tr);
                    });
                    renderizarGrafico(data.estatisticas);
                } catch (err) { console.error(err); }
            }

            function filtrarTicker(t) { carregarDados(t); }

            function renderizarGrafico(estat) {
                const ctx = document.getElementById('graficoTese').getContext('2d');
                if(meuGrafico) meuGrafico.destroy();
                meuGrafico = new Chart(ctx, {
                    type: 'bar',
                    data: {
                        labels: ['Positivo (Bullish)', 'Neutro', 'Negativo (Bearish)'],
                        datasets: [{ data: [estat.positivo, estat.neutro, estat.negativo], backgroundColor: ['#10B981', '#F59E0B', '#EF4444'], borderRadius: 6 }]
                    },
                    options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } } }
                });
            }
            carregarDados('TODOS');
        </script>
    </body>
    </html>
    """
