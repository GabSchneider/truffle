from fastapi import FastAPI
from fastapi.responses import HTMLResponse
import feedparser
from datetime import datetime
import sqlite3

app = FastAPI(title="Truffle Finder - Terminal Institucional B3", version="10.0")
DB_FILE = "truffle_history.db"

def init_db():
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS noticias (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            titulo TEXT UNIQUE,
            fonte TEXT,
            data TEXT,
            link TEXT,
            ticker TEXT,
            setor TEXT,
            sentimento TEXT,
            score_nlp REAL
        )
    ''')
    conn.commit()
    conn.close()

init_db()

# Dicionário robusto do Ibovespa para varredura real
IBOV_MAPA = {
    "PETR4": {"nome": "Petrobras", "setor": "Petróleo e Gás"},
    "VALE3": {"nome": "Vale", "setor": "Materiais Básicos"},
    "ITUB4": {"nome": "Itaú Unibanco", "setor": "Financeiro"},
    "BBDC4": {"nome": "Bradesco", "setor": "Financeiro"},
    "ABEV3": {"nome": "Ambev", "setor": "Consumo Não Cíclico"},
    "MGLU3": {"nome": "Magazine Luiza", "setor": "Consumo Cíclico"}
}

RSS_FEEDS = [
    {"name": "Valor Econômico", "url": "https://valor.globo.com/rss/"},
    {"name": "InfoMoney", "url": "https://www.infomoney.com.br/feed/"}
]

def analisar_nlp(texto: str):
    t_lower = texto.lower()
    positivas = ["alta", "lucro", "crescimento", "disparou", "positivo", "superou", "recorde", "expansão", "dividendo", "valorização", "avanço"]
    negativas = ["queda", "prejuízo", "crise", "despencou", "negativo", "investigação", "falência", "corte", "processo", "retração"]
    
    score = 0.0
    for p in positivas:
        if p in t_lower: score += 0.25
    for n in negativas:
        if n in t_lower: score -= 0.25
        
    score = max(min(score, 1.0), -1.0)
    if score > 0.05: label = "Positivo"
    elif score < -0.05: label = "Negativo"
    else: label = "Neutro"
    return label, round(score, 2)

def sincronizar_rss():
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    for fonte in RSS_FEEDS:
        try:
            feed = feedparser.parse(fonte["url"])
            for entry in feed.entries[:20]:
                titulo = entry.get("title", "")
                link = entry.get("link", "")
                data_pub = entry.get("published", str(datetime.now()))[:16]
                
                ticker_enq = "IBOV / GERAL"
                setor_enq = "Macroeconomia"
                for t, info in IBOV_MAPA.items():
                    if t.lower() in titulo.lower() or info["nome"].lower() in titulo.lower():
                        ticker_enq = t
                        setor_enq = info["setor"]
                        break
                
                sentimento, score = analisar_nlp(titulo)
                try:
                    cursor.execute('''
                        INSERT INTO noticias (titulo, fonte, data, link, ticker, setor, sentimento, score_nlp)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    ''', (titulo, fonte["name"], data_pub, link, ticker_enq, setor_enq, sentimento, score))
                except sqlite3.IntegrityError:
                    pass
        except Exception:
            continue
    conn.commit()
    conn.close()

@app.get("/api/dados")
def api_dados(ticker: str = "TODOS"):
    sincronizar_rss()
    conn = sqlite3.connect(DB_FILE)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    
    if ticker and ticker != "TODOS":
        cursor.execute("SELECT * FROM noticias WHERE ticker = ? ORDER BY id DESC LIMIT 40", (ticker,))
    else:
        cursor.execute("SELECT * FROM noticias ORDER BY id DESC LIMIT 40")
        
    rows = cursor.fetchall()
    noticias = [dict(r) for r in rows]
    
    cursor.execute("SELECT COUNT(*) FROM noticias")
    total = cursor.fetchone()[0]
    cursor.execute("SELECT COUNT(*) FROM noticias WHERE sentimento='Positivo'")
    pos = cursor.fetchone()[0]
    cursor.execute("SELECT COUNT(*) FROM noticias WHERE sentimento='Negativo'")
    neg = cursor.fetchone()[0]
    
    conn.close()
    return {
        "status": "sucesso",
        "total": total,
        "estatisticas": {"positivo": pos, "negativo": neg, "neutro": max(total - pos - neg, 0)},
        "noticias": noticias
    }

@app.get("/", response_class=HTMLResponse)
def index():
    return """
    <!DOCTYPE html>
    <html lang="pt-BR">
    <head>
        <meta charset="UTF-8">
        <title>Truffle Finder - Terminal Institucional B3</title>
        <script src="https://cdn.tailwindcss.com"></script>
        <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    </head>
    <body class="bg-slate-950 text-slate-100 font-sans flex h-screen overflow-hidden">

        <aside class="w-72 bg-slate-900 border-r border-slate-800 flex flex-col justify-between p-6 shadow-2xl">
            <div>
                <div class="flex items-center gap-3 mb-8 pb-4 border-b border-slate-800">
                    <div class="bg-gradient-to-br from-blue-600/30 to-blue-900/40 p-2.5 rounded-2xl border border-blue-500/40 shadow flex items-center justify-center">
                        <span class="text-2xl">🐷</span>
                    </div>
                    <div>
                        <h1 class="text-base font-black tracking-wider text-white">TRUFFLE<span class="text-blue-500">FINDER</span></h1>
                        <p class="text-[10px] text-slate-400 uppercase tracking-widest font-semibold">Intelligence Terminal</p>
                    </div>
                </div>

                <div class="space-y-6">
                    <div>
                        <p class="text-[10px] font-bold uppercase tracking-widest text-slate-400 mb-3">Módulos Analíticos</p>
                        <nav class="space-y-1.5">
                            <button onclick="mudarModulo('dashboard')" id="btn-dashboard" class="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-xs font-semibold bg-blue-600 text-white transition text-left shadow">📊 Dashboard Executivo</button>
                            <button onclick="mudarModulo('fontes')" id="btn-fontes" class="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-xs font-semibold text-slate-400 hover:bg-slate-800 hover:text-white transition text-left">🔍 Classificação de Fontes</button>
                            <button onclick="mudarModulo('setores')" id="btn-setores" class="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-xs font-semibold text-slate-400 hover:bg-slate-800 hover:text-white transition text-left">🎯 Análise Setorial B3</button>
                            <button onclick="mudarModulo('preferencias')" id="btn-preferencias" class="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-xs font-semibold text-slate-400 hover:bg-slate-800 hover:text-white transition text-left">⚙️ Preferências & Alertas</button>
                        </nav>
                    </div>

                    <div>
                        <p class="text-[10px] font-bold uppercase tracking-widest text-slate-400 mb-3">Filtro Rápido Ibovespa</p>
                        <div class="grid grid-cols-2 gap-1.5">
                            <button onclick="filtrarTicker('TODOS')" class="px-2 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-xs font-mono text-slate-200 text-center transition ticker-btn shadow-inner" data-ticker="TODOS">🌐 TODOS</button>
                            <button onclick="filtrarTicker('PETR4')" class="px-2 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-xs font-mono text-slate-200 text-center transition ticker-btn" data-ticker="PETR4">⚡ PETR4</button>
                            <button onclick="filtrarTicker('VALE3')" class="px-2 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-xs font-mono text-slate-200 text-center transition ticker-btn" data-ticker="VALE3">⛏️ VALE3</button>
                            <button onclick="filtrarTicker('ITUB4')" class="px-2 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-xs font-mono text-slate-200 text-center transition ticker-btn" data-ticker="ITUB4">🏦 ITUB4</button>
                            <button onclick="filtrarTicker('BBDC4')" class="px-2 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-xs font-mono text-slate-200 text-center transition ticker-btn" data-ticker="BBDC4">💳 BBDC4</button>
                            <button onclick="filtrarTicker('ABEV3')" class="px-2 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-xs font-mono text-slate-200 text-center transition ticker-btn" data-ticker="ABEV3">🍺 ABEV3</button>
                        </div>
                    </div>
                </div>
            </div>

            <div class="pt-4 border-t border-slate-800 text-[11px] text-slate-500 flex justify-between items-center">
                <span>Sessão: Gestor B3</span>
                <span class="text-emerald-400 font-semibold animate-pulse">● Online</span>
            </div>
        </aside>

        <main class="flex-1 flex flex-col overflow-y-auto p-8">
            <header class="flex justify-between items-center mb-8 pb-4 border-b border-slate-800">
                <div>
                    <h2 id="titulo-topo" class="text-2xl font-bold text-slate-100">Dashboard Executivo & Tese NLP</h2>
                    <p class="text-xs text-slate-400 mt-1">Filtro ativo: <span id="filtro-ativo-txt" class="text-blue-400 font-bold">TODOS</span></p>
                </div>
                <button onclick="carregarDados(tickerAtual)" class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-xs font-semibold transition shadow">🔄 Atualizar Terminal</button>
            </header>

            <div id="modulo-dashboard" class="space-y-6">
                <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div class="bg-slate-900 p-6 rounded-xl border border-slate-800 shadow">
                        <h3 class="text-slate-400 text-xs font-bold uppercase tracking-wider">Total de Artigos</h3>
                        <p id="stat-total" class="text-3xl font-bold text-white mt-2">-</p>
                    </div>
                    <div class="bg-slate-900 p-6 rounded-xl border border-slate-800 shadow">
                        <h3 class="text-slate-400 text-xs font-bold uppercase tracking-wider">Viés de Sentimento</h3>
                        <p id="stat-vies" class="text-3xl font-bold text-emerald-400 mt-2">Bullish (Positivo)</p>
                    </div>
                    <div class="bg-slate-900 p-6 rounded-xl border border-slate-800 shadow">
                        <h3 class="text-slate-400 text-xs font-bold uppercase tracking-wider">Ativo em Foco</h3>
                        <p id="stat-ativo-card" class="text-3xl font-bold text-blue-400 mt-2">TODOS</p>
                    </div>
                </div>

                <div class="bg-slate-900 p-6 rounded-xl border border-slate-800 shadow">
                    <h3 class="text-sm font-bold text-slate-200 mb-4">📈 Tese Analítica: Distribuição de Sentimento por NLP</h3>
                    <div style="height: 260px;"><canvas id="graficoNLP"></canvas></div>
                </div>

                <div class="bg-slate-900 rounded-xl border border-slate-800 p-6 shadow">
                    <h3 class="text-sm font-bold text-slate-200 mb-4">Stream de Notícias & Insights Lexicais</h3>
                    <div class="overflow-x-auto">
                        <table class="w-full text-left border-collapse">
                            <thead>
                                <tr class="border-b border-slate-800 text-slate-400 text-[11px] uppercase tracking-wider">
                                    <th class="p-3">Data</th>
                                    <th class="p-3">Ticker</th>
                                    <th class="p-3">Setor</th>
                                    <th class="p-3">Título & Link</th>
                                    <th class="p-3">Fonte</th>
                                    <th class="p-3">Sentimento (NLP)</th>
                                </tr>
                            </thead>
                            <tbody id="tabela-corpo" class="divide-y divide-slate-800/60 text-sm">
                                <tr><td colspan="6" class="p-6 text-center text-slate-500">A carregar registos...</td></tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <div id="modulo-fontes" class="hidden space-y-6">
                <div class="bg-slate-900 rounded-xl border border-slate-800 p-6">
                    <h3 class="text-lg font-bold text-slate-200 mb-4">🔍 Credibilidade e Ponderação de Fontes</h3>
                    <p class="text-xs text-slate-400 mb-6">O Truffle Finder categoriza rigorosamente os canais de informação para filtrar ruído de mercado.</p>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div class="bg-slate-950 p-5 rounded-lg border border-slate-800">
                            <h4 class="text-sm font-bold text-emerald-400 mb-2">🟢 Fontes Confiáveis / Oficiais</h4>
                            <p class="text-xs text-slate-400">Valor Econômico, InfoMoney, Broadcast e comunicados institucionais de RI.</p>
                        </div>
                        <div class="bg-slate-950 p-5 rounded-lg border border-slate-800">
                            <h4 class="text-sm font-bold text-rose-400 mb-2">🟠 Mídias Alternativas / Rumores</h4>
                            <p class="text-xs text-slate-400">Redes sociais e fóruns de curto prazo filtrados com menor ponderação analítica.</p>
                        </div>
                    </div>
                </div>
            </div>

            <div id="modulo-setores" class="hidden space-y-6">
                <div class="bg-slate-900 rounded-xl border border-slate-800 p-6">
                    <h3 class="text-lg font-bold text-slate-200 mb-4">🎯 Macrosetores da B3 Monitorados</h3>
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div class="bg-slate-950 p-4 rounded-lg border border-slate-800"><h4 class="font-bold text-blue-400 text-sm">Petróleo e Gás</h4><p class="text-xs text-slate-400 mt-1">PETR4</p></div>
                        <div class="bg-slate-950 p-4 rounded-lg border border-slate-800"><h4 class="font-bold text-blue-400 text-sm">Financeiro & Bancos</h4><p class="text-xs text-slate-400 mt-1">ITUB4, BBDC4</p></div>
                        <div class="bg-slate-950 p-4 rounded-lg border border-slate-800"><h4 class="font-bold text-blue-400 text-sm">Materiais Básicos</h4><p class="text-xs text-slate-400 mt-1">VALE3</p></div>
                    </div>
                </div>
            </div>

            <div id="modulo-preferencias" class="hidden space-y-6">
                <div class="bg-slate-900 rounded-xl border border-slate-800 p-6 max-w-xl">
                    <h3 class="text-lg font-bold text-slate-200 mb-4">⚙️ Configurações de Alertas</h3>
                    <div class="space-y-4">
                        <div><label class="block text-xs font-semibold text-slate-400 mb-1">E-mail para Volatilidade</label><input type="email" value="gestor@trufflefinder.com.br" class="w-full bg-slate-950 border border-slate-800 rounded px-3 py-2 text-xs text-slate-200"></div>
                        <button onclick="alert('Guardado com sucesso!')" class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded text-xs font-semibold transition">Guardar Alterações</button>
                    </div>
                </div>
            </div>
        </main>

        <script>
            let tickerAtual = 'TODOS';
            let chartInstancia = null;

            function mudarModulo(mod) {
                ['dashboard', 'fontes', 'setores', 'preferencias'].forEach(m => {
                    document.getElementById(`modulo-${m}`).classList.add('hidden');
                    document.getElementById(`btn-${m}`).className = "w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-xs font-semibold text-slate-400 hover:bg-slate-800 hover:text-white transition text-left";
                });
                document.getElementById(`modulo-${mod}`).classList.remove('hidden');
                document.getElementById(`btn-${mod}`).className = "w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-xs font-semibold bg-blue-600 text-white transition text-left shadow";
                
                const titulos = {
                    'dashboard': 'Dashboard Executivo & Tese NLP',
                    'fontes': 'Classificação de Fontes de Mercado',
                    'setores': 'Análise por Macrosetores da B3',
                    'preferencias': 'Preferências e Alertas do Sistema'
                };
                document.getElementById('titulo-topo').innerText = titulos[mod];
            }

            async function carregarDados(ticker = 'TODOS') {
                tickerAtual = ticker;
                document.getElementById('filtro-ativo-txt').innerText = ticker;
                document.getElementById('stat-ativo-card').innerText = ticker;
                
                document.querySelectorAll('.ticker-btn').forEach(btn => {
                    if(btn.getAttribute('data-ticker') === ticker) {
                        btn.className = "px-2 py-1.5 rounded bg-blue-600 text-white text-xs font-mono text-center transition ticker-btn shadow";
                    } else {
                        btn.className = "px-2 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-xs font-mono text-slate-200 text-center transition ticker-btn";
                    }
                });

                try {
                    const res = await fetch(`/api/dados?ticker=${ticker}`);
                    const data = await res.json();
                    
                    document.getElementById('stat-total').innerText = data.total;
                    
                    const tbody = document.getElementById('tabela-corpo');
                    tbody.innerHTML = '';
                    
                    if(data.noticias.length === 0) {
                        tbody.innerHTML = '<tr><td colspan="6" class="p-6 text-center text-slate-500">Nenhum registo encontrado para este ativo.</td></tr>';
                        return;
                    }
                    
                    data.noticias.forEach(n => {
                        let badge = 'bg-slate-800 text-slate-300 border-slate-700';
                        if(n.sentimento === 'Positivo') badge = 'bg-emerald-950 text-emerald-400 border-emerald-800';
                        if(n.sentimento === 'Negativo') badge = 'bg-rose-950 text-rose-400 border-rose-800';
                        
                        const tr = document.createElement('tr');
                        tr.className = 'hover:bg-slate-800/40 transition';
                        tr.innerHTML = `
                            <td class="p-3 text-slate-400 text-xs whitespace-nowrap">${n.data}</td>
                            <td class="p-3 font-mono font-bold text-blue-400">${n.ticker}</td>
                            <td class="p-3 text-slate-300 text-xs">${n.setor}</td>
                            <td class="p-3"><a href="${n.link}" target="_blank" class="hover:text-blue-400 transition text-slate-100">${n.titulo}</a></td>
                            <td class="p-3 text-xs text-slate-400">${n.fonte}</td>
                            <td class="p-3"><span class="px-2.5 py-1 rounded-full text-xs font-semibold border ${badge}">${n.sentimento} (${n.score_nlp})</span></td>
                        `;
                        tbody.appendChild(tr);
                    });

                    renderizarGrafico(data.estatisticas);
                } catch (err) {
                    console.error("Erro ao carregar dados:", err);
                }
            }

            function filtrarTicker(t) {
                carregarDados(t);
            }

            function renderizarGrafico(estat) {
                const ctx = document.getElementById('graficoNLP').getContext('2d');
                if(chartInstancia) chartInstancia.destroy();
                
                chartInstancia = new Chart(ctx, {
                    type: 'bar',
                    data: {
                        labels: ['Positivo (Bullish)', 'Neutro', 'Negativo (Bearish)'],
                        datasets: [{
                            data: [estat.positivo, estat.neutro, estat.negativo],
                            backgroundColor: ['#10B981', '#F59E0B', '#EF4444'],
                            borderRadius: 6
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: { legend: { display: false } },
                        scales: {
                            x: { grid: { display: false }, ticks: { color: '#94A3B8' } },
                            y: { grid: { color: '#1E293B' }, ticks: { color: '#94A3B8' } }
                        }
                    }
                });
            }

            carregarDados('TODOS');
        </script>
    </body>
    </html>
    """
