from fastapi import FastAPI, Form
from fastapi.responses import HTMLResponse, RedirectResponse
import feedparser
from datetime import datetime, timedelta
import sqlite3

app = FastAPI(title="Truffle Finder API", description="Inteligência Institucional e Agregação B3", version="2.0.0")

DB_NAME = "truffle_settings.db"

def init_db():
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS alerts_config (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT NOT NULL,
            sector TEXT NOT NULL,
            min_sentiment REAL NOT NULL,
            active INTEGER NOT NULL
        )
    ''')
    conn.commit()
    conn.close()

init_db()

INITIAL_NEWS = [
    {
        "id": 1,
        "titulo": "Petrobras (PETR3) anuncia nova diretriz de investimentos para o pré-sal",
        "fonte": "Valor Econômico",
        "data": datetime.now().strftime("%Y-%m-%d %H:%M"),
        "link": "https://www.valor.com.br",
        "ticker": "PETR3",
        "setor": "Petróleo, Gás e Biocombustíveis",
        "pais": "Brasil",
        "sentimento": "Positivo",
        "confiabilidade": "Confiável"
    },
    {
        "id": 2,
        "titulo": "Vale (VALE3) registra oscilação nos contratos de minério de ferro na China",
        "fonte": "InfoMoney",
        "data": (datetime.now() - timedelta(hours=2)).strftime("%Y-%m-%d %H:%M"),
        "link": "https://www.infomoney.com.br",
        "ticker": "VALE3",
        "setor": "Materiais Básicos",
        "pais": "Brasil",
        "sentimento": "Neutro",
        "confiabilidade": "Confiável"
    },
    {
        "id": 3,
        "titulo": "Itaú Unibanco (ITUB4) expande carteira de crédito corporativo no trimestre",
        "fonte": "Exame",
        "data": (datetime.now() - timedelta(hours=4)).strftime("%Y-%m-%d %H:%M"),
        "link": "https://exame.com",
        "ticker": "ITUB4",
        "setor": "Financeiro",
        "pais": "Brasil",
        "sentimento": "Positivo",
        "confiabilidade": "Confiável"
    },
    {
        "id": 4,
        "titulo": "Magazine Luiza (MGLU3) enfrenta desafios com o varejo digital e juros altos",
        "fonte": "CNN Brasil",
        "data": (datetime.now() - timedelta(hours=6)).strftime("%Y-%m-%d %H:%M"),
        "link": "https://www.cnnbrasil.com.br",
        "ticker": "MGLU3",
        "setor": "Consumo Cíclico",
        "pais": "Brasil",
        "sentimento": "Negativo",
        "confiabilidade": "Média"
    },
    {
        "id": 5,
        "titulo": "Ambev (ABEV3) aposta em novas linhas de bebidas saudáveis para o verão",
        "fonte": "UOL Economia",
        "data": (datetime.now() - timedelta(hours=8)).strftime("%Y-%m-%d %H:%M"),
        "link": "https://economia.uol.com.br",
        "ticker": "ABEV3",
        "setor": "Consumo Não Cíclico",
        "pais": "Brasil",
        "sentimento": "Misto",
        "confiabilidade": "Média"
    }
]

@app.get("/api/news")
def get_news(ticker: str = None, setor: str = None):
    results = INITIAL_NEWS
    if ticker:
        results = [n for n in results if n["ticker"].upper() == ticker.upper()]
    if setor:
        results = [n for n in results if n["setor"].lower() == setor.lower()]
    return results

@app.get("/api/sectors")
def get_sector_metrics():
    sectors_data = {
        "Petróleo, Gás e Biocombustíveis": {"Positivo": 12, "Negativo": 2, "Neutro": 4},
        "Materiais Básicos": {"Positivo": 8, "Negativo": 6, "Neutro": 9},
        "Financeiro": {"Positivo": 15, "Negativo": 3, "Neutro": 5},
        "Consumo Cíclico": {"Positivo": 4, "Negativo": 11, "Neutro": 3},
        "Consumo Não Cíclico": {"Positivo": 7, "Negativo": 4, "Neutro": 6}
    }
    return sectors_data

@app.post("/api/preferences")
def save_preferences(email: str = Form(...), sector: str = Form(...), min_sentiment: float = Form(...)):
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute("INSERT INTO alerts_config (email, sector, min_sentiment, active) VALUES (?, ?, ?, 1)", (email, sector, min_sentiment))
    conn.commit()
    conn.close()
    return {"status": "success", "message": f"Preferências de alerta para {email} salvas com sucesso!"}

@app.get("/api/preferences")
def get_preferences():
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute("SELECT email, sector, min_sentiment FROM alerts_config ORDER BY id DESC LIMIT 1")
    row = cursor.fetchone()
    conn.close()
    if row:
        return {"email": row[0], "sector": row[1], "min_sentiment": row[2]}
    return {"email": "", "sector": "", "min_sentiment": 0.5}

@app.get("/", response_class=HTMLResponse)
def dashboard():
    return """
    <!DOCTYPE html>
    <html lang="pt-BR">
    <head>
        <meta charset="UTF-8">
        <title>Truffle Finder | Intelligence Terminal</title>
        <script src="https://cdn.tailwindcss.com"></script>
        <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    </head>
    <body class="bg-slate-950 text-slate-100 font-sans">
        <div class="flex h-screen overflow-hidden">
            <div class="w-64 bg-slate-900 border-r border-slate-800 flex flex-col justify-between">
                <div class="p-5">
                    <h1 class="text-xl font-bold text-emerald-400 tracking-wider">TRUFFLE FINDER</h1>
                    <p class="text-xs text-slate-400 mt-1">B3 Institutional Terminal</p>
                    <nav class="mt-8 space-y-2">
                        <button onclick="switchTab('dashboard')" id="btn-dashboard" class="w-full text-left px-4 py-2 rounded bg-emerald-600 text-white font-medium">📊 Dashboard & Feed</button>
                        <button onclick="switchTab('sectors')" id="btn-sectors" class="w-full text-left px-4 py-2 rounded hover:bg-slate-800 text-slate-300">📈 Correlação Setorial</button>
                        <button onclick="switchTab('preferences')" id="btn-preferences" class="w-full text-left px-4 py-2 rounded hover:bg-slate-800 text-slate-300">⚙️ Preferências & Alertas</button>
                    </nav>
                </div>
                <div class="p-4 border-t border-slate-800 text-xs text-slate-500">
                    VPS Status: <span class="text-emerald-400 font-semibold">Online (Docker)</span>
                </div>
            </div>

            <div class="flex-1 flex flex-col overflow-y-auto">
                <header class="bg-slate-900 border-b border-slate-800 p-4 flex justify-between items-center">
                    <h2 id="page-title" class="text-lg font-semibold text-slate-200">Visão Geral do Mercado</h2>
                    <span class="text-sm bg-slate-800 px-3 py-1 rounded border border-slate-700">Ibovespa / B3</span>
                </header>

                <main class="p-6">
                    <div id="tab-dashboard" class="space-y-6">
                        <div class="flex gap-4 mb-4">
                            <input type="text" id="search-ticker" placeholder="Filtrar por Ticker (ex: PETR3)..." class="bg-slate-900 border border-slate-700 px-4 py-2 rounded text-sm w-72 focus:outline-none focus:border-emerald-500">
                            <button onclick="fetchNews()" class="bg-emerald-600 hover:bg-emerald-500 px-4 py-2 rounded text-sm font-medium transition">Pesquisar</button>
                        </div>
                        <div class="bg-slate-900 border border-slate-800 rounded-lg p-5">
                            <h3 class="text-md font-medium mb-4 text-emerald-400">Notícias e Sentimento em Tempo Real</h3>
                            <div id="news-container" class="space-y-4">
                                </div>
                        </div>
                    </div>

                    <div id="tab-sectors" class="hidden space-y-6">
                        <div class="bg-slate-900 border border-slate-800 rounded-lg p-5 max-w-3xl">
                            <h3 class="text-md font-medium mb-4 text-emerald-400">Análise de Sentimento por Macrosetor (B3)</h3>
                            <canvas id="sectorChart"></canvas>
                        </div>
                    </div>

                    <div id="tab-preferences" class="hidden space-y-6">
                        <div class="bg-slate-900 border border-slate-800 rounded-lg p-6 max-w-xl">
                            <h3 class="text-md font-medium mb-4 text-emerald-400">Configuração de Alertas Automáticos</h3>
                            <form id="pref-form" onsubmit="savePreferences(event)" class="space-y-4">
                                <div>
                                    <label class="block text-xs text-slate-400 mb-1">E-mail para Alertas</label>
                                    <input type="email" id="pref-email" required class="w-full bg-slate-950 border border-slate-700 px-3 py-2 rounded text-sm focus:outline-none focus:border-emerald-500">
                                </div>
                                <div>
                                    <label class="block text-xs text-slate-400 mb-1">Macrosetor Monitorado</label>
                                    <select id="pref-sector" class="w-full bg-slate-950 border border-slate-700 px-3 py-2 rounded text-sm focus:outline-none focus:border-emerald-500">
                                        <option value="Petróleo, Gás e Biocombustíveis">Petróleo, Gás e Biocombustíveis</option>
                                        <option value="Materiais Básicos">Materiais Básicos</option>
                                        <option value="Financeiro">Financeiro</option>
                                        <option value="Consumo Cíclico">Consumo Cíclico</option>
                                        <option value="Consumo Não Cíclico">Consumo Não Cíclico</option>
                                    </select>
                                </div>
                                <div>
                                    <label class="block text-xs text-slate-400 mb-1">Sensibilidade Mínima (0.0 a 1.0)</label>
                                    <input type="number" step="0.1" min="0" max="1" id="pref-sentiment" required class="w-full bg-slate-950 border border-slate-700 px-3 py-2 rounded text-sm focus:outline-none focus:border-emerald-500">
                                </div>
                                <button type="submit" class="bg-emerald-600 hover:bg-emerald-500 px-4 py-2 rounded text-sm font-medium transition w-full">Gravar Preferências</button>
                            </form>
                            <div id="pref-status" class="mt-3 text-xs text-emerald-400"></div>
                        </div>
                    </div>
                </main>
            </div>
        </div>

        <script>
            let sectorChartInstance = null;

            function switchTab(tab) {
                ['dashboard', 'sectors', 'preferences'].forEach(t => {
                    document.getElementById(`tab-${t}`).classList.add('hidden');
                    document.getElementById(`btn-${t}`).className = "w-full text-left px-4 py-2 rounded hover:bg-slate-800 text-slate-300";
                });

                const titles = {
                    'dashboard': 'Visão Geral do Mercado',
                    'sectors': 'Correlação Setorial',
                    'preferences': '⚙️ Preferências & Alertas'
                };
                document.getElementById('page-title').innerText = titles[tab];
                document.getElementById(`tab-${tab}`).classList.remove('hidden');
                document.getElementById(`btn-${tab}`).className = "w-full text-left px-4 py-2 rounded bg-emerald-600 text-white font-medium";

                if (tab === 'sectors') loadSectorChart();
                if (tab === 'preferences') loadPreferences();
            }

            async function fetchNews() {
                const ticker = document.getElementById('search-ticker').value;
                let url = '/api/news';
                if (ticker) url += `?ticker=${ticker}`;

                const res = await fetch(url);
                const data = await res.json();
                const container = document.getElementById('news-container');
                container.innerHTML = '';

                data.forEach(n => {
                    container.innerHTML += `
                        <div class="p-4 bg-slate-950 border border-slate-800 rounded flex justify-between items-start">
                            <div>
                                <span class="text-xs font-bold text-emerald-400 bg-emerald-950/50 px-2 py-0.5 rounded border border-emerald-900">${n.ticker}</span>
                                <span class="text-xs text-slate-400 ml-2">${n.setor}</span>
                                <h4 class="text-sm font-semibold mt-1 text-slate-200"><a href="${n.link}" target="_blank" class="hover:underline">${n.titulo}</a></h4>
                                <p class="text-xs text-slate-500 mt-1">Fonte: ${n.fonte} •${n.data}</p>
                            </div>
                            <span class="text-xs px-2 py-1 rounded font-medium ${n.sentimento === 'Positivo' ? 'bg-emerald-950 text-emerald-400 border border-emerald-900' : n.sentimento === 'Negativo' ? 'bg-rose-950 text-rose-400 border border-rose-900' : 'bg-slate-800 text-slate-300'}">${n.sentimento}</span>
                        </div>
                    `;
                });
            }

            async function loadSectorChart() {
                const res = await fetch('/api/sectors');
                const data = await res.json();
                
                const labels = Object.keys(data);
                const positivos = labels.map(l => data[l].Positivo);
                const negativos = labels.map(l => data[l].Negativo);

                const ctx = document.getElementById('sectorChart').getContext('2d');
                if (sectorChartInstance) sectorChartInstance.destroy();

                sectorChartInstance = new Chart(ctx, {
                    type: 'bar',
                    data: {
                        labels: labels,
                        datasets: [
                            { label: 'Sentimento Positivo', data: positivos, backgroundColor: '#10b981' },
                            { label: 'Sentimento Negativo', data: negativos, backgroundColor: '#f43f5e' }
                        ]
                    },
                    options: {
                        responsive: true,
                        plugins: { legend: { labels: { color: '#cbd5e1' } } },
                        scales: {
                            x: { ticks: { color: '#94a3b8' }, grid: { color: '#1e293b' } },
                            y: { ticks: { color: '#94a3b8' }, grid: { color: '#1e293b' } }
                        }
                    }
                });
            }

            async function loadPreferences() {
                const res = await fetch('/api/preferences');
                const data = await res.json();
                if (data.email) {
                    document.getElementById('pref-email').value = data.email;
                    document.getElementById('pref-sector').value = data.sector;
                    document.getElementById('pref-sentiment').value = data.min_sentiment;
                }
            }

            async function savePreferences(e) {
                e.preventDefault();
                const formData = new URLSearchParams();
                formData.append('email', document.getElementById('pref-email').value);
                formData.append('sector', document.getElementById('pref-sector').value);
                formData.append('min_sentiment', document.getElementById('pref-sentiment').value);

                const res = await fetch('/api/preferences', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: formData
                });
                const data = await res.json();
                document.getElementById('pref-status').innerText = data.message;
            }

            fetchNews();
        </script>
    </body>
    </html>
    """
