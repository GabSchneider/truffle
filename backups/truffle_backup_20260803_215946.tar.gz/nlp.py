import feedparser
from datetime import datetime
from database import salvar_noticia

IBOV_MAPA = {
    "PETR4": {"nome": "Petrobras", "setor": "Petróleo, Gás e Biocombustíveis"},
    "VALE3": {"nome": "Vale", "setor": "Materiais Básicos"},
    "ITUB4": {"nome": "Itaú Unibanco", "setor": "Financeiro"},
    "BBDC4": {"nome": "Bradesco", "setor": "Financeiro"},
    "ABEV3": {"nome": "Ambev", "setor": "Consumo Não Cíclico"},
    "MGLU3": {"nome": "Magazine Luiza", "setor": "Consumo Cíclico"},
    "WEGE3": {"nome": "Weg", "setor": "Bens Industriais"},
    "SUZB3": {"nome": "Suzano", "setor": "Papel e Celulose"}
}

RSS_FEEDS = [
    {"name": "Valor Econômico", "url": "https://valor.globo.com/rss/"},
    {"name": "InfoMoney", "url": "https://www.infomoney.com.br/feed/"}
]

def analisar_nlp(texto: str):
    t_lower = texto.lower()
    positivas = ["alta", "lucro", "crescimento", "disparou", "positivo", "superou", "recorde", "expansão", "dividendo", "valorização", "avanço"]
    negativas = ["queda", "prejuízo", "crise", "despencou", "negativo", "investigação", "falência", "corte", "processo", "retração"]
    
    score = 0.0
    for p in positivas:
        if p in t_lower: score += 0.25
    for n in negativas:
        if n in t_lower: score -= 0.25
        
    score = max(min(score, 1.0), -1.0)
    if score > 0.05: label = "Positivo"
    elif score < -0.05: label = "Negativo"
    else: label = "Neutro"
    return label, round(score, 2)

def processar_feeds():
    """Motor central de varredura e normalização de feeds RSS para o banco de dados"""
    novas_coletas = 0
    for fonte in RSS_FEEDS:
        try:
            feed = feedparser.parse(fonte["url"])
            for entry in feed.entries[:20]:
                titulo = entry.get("title", "")
                link = entry.get("link", "")
                data_pub = entry.get("published", str(datetime.now()))[:16]
                
                ticker_enq = "IBOV / GERAL"
                setor_enq = "Macroeconomia"
                for t, info in IBOV_MAPA.items():
                    if t.lower() in titulo.lower() or info["nome"].lower() in titulo.lower():
                        ticker_enq = t
                        setor_enq = info["setor"]
                        break
                
                sentimento, score = analisar_nlp(titulo)
                salvar_noticia({
                    "titulo": titulo,
                    "fonte": fonte["name"],
                    "data": data_pub,
                    "link": link,
                    "ticker": ticker_enq,
                    "setor": setor_enq,
                    "sentimento": sentimento,
                    "score_nlp": score
                })
                novas_coletas += 1
        except Exception:
            continue
    return novas_coletas
