from fastapi import FastAPI, HTTPException
from fastapi.responses import HTMLResponse
from pydantic import BaseModel
import feedparser
from datetime import datetime
import re

app = FastAPI(title="Truffle Finder - Terminal Ibovespa", version="2.0")

# Lista expandida com os principais tickers e empresas do Ibovespa (modular e expansível)
IBOV_COMPANIES = {
    "PETR4": {"nome": "Petrobras", "setor": "Petróleo, Gás e Biocombustíveis"},
    "PETR3": {"nome": "Petrobras ON", "setor": "Petróleo, Gás e Biocombustíveis"},
    "VALE3": {"nome": "Vale", "setor": "Mineração / Materiais Básicos"},
    "ITUB4": {"nome": "Itaú Unibanco", "setor": "Financeiro e Outros"},
    "BBDC4": {"nome": "Bradesco", "setor": "Financeiro e Outros"},
    "BBAS3": {"nome": "Banco do Brasil", "setor": "Financeiro e Outros"},
    "ABEV3": {"nome": "Ambev", "setor": "Consumo Não Cíclico"},
    "MGLU3": {"nome": "Magazine Luiza", "setor": "Consumo Cíclico"},
    "WEGE3": {"nome": "Weg", "setor": "Bens Industriais"},
    "RENT3": {"nome": "Localiza", "setor": "Consumo Cíclico"},
    "JBSS3": {"nome": "JBS", "setor": "Consumo Não Cíclico"},
    "SUZB3": {"nome": "Suzano", "setor": "Papel e Celulose"}
}

# Feeds RSS financeiros de referência no Brasil
RSS_FEEDS = [
    "https://infomoney.com.br/feed/",
    "https://valor.globo.com/rss/"
]

def analisar_sentimento(texto: str) -> str:
    texto_lower = texto.lower()
    positivas = ["alta", "lucro", "crescimento", "disparou", "positivo", "superou", "recorde", "expansão", "dividendo", "valorização"]
    negativas = ["queda", "prejuízo", "crise", "despabou", "negativo", "investigação", "Queda", "falência", "corte", "processo"]
    
    score = 0
    for p in positivas:
        if p in texto_lower:
            score += 1
    for n in negativas:
        if n in texto_lower:
            score -= 1
            
    if score > 0:
        return "Positivo"
    elif score < 0:
        return "Negativo"
    return "Neutro"

@app.get("/api/noticias")
def obter_noticias():
    noticias = []
    
    for url_feed in RSS_FEEDS:
        try:
            feed = feedparser.parse(url_feed)
            for entry in feed.entries[:15]: # Coleta os 15 mais recentes de cada fonte
                titulo = entry.get("title", "")
                link = entry.get("link", "")
                data_publicacao = entry.get("published", str(datetime.now()))
                
                # Identifica qual empresa/ticker do Ibovespa é citada no título ou sumário
                ticker_encontrado = "GERAL / IBOV"
                setor_encontrado = "Mercado de Capitais"
                
                for ticker, info in IBOV_COMPANIES.items():
                    if ticker.lower() in titulo.lower() or info["nome"].lower() in titulo.lower():
                        ticker_encontrado = ticker
                        setor_encontrado = info["setor"]
                        break
                
                sentimento = analisar_sentimento(titulo)
                
                noticias.append({
                    "titulo": titulo,
                    "fonte": "InfoMoney / Valor" if "infomoney" in url_feed else "Valor Econômico",
                    "data": data_publicacao,
                    "link": link,
                    "ticker": ticker_encontrado,
                    "setor": setor_encontrado,
                    "sentimento": sentimento
                })
        except Exception as e:
            continue
            
    return {"status": "sucesso", "total_empresas_monitoradas": len(IBOV_COMPANIES), "noticias": noticias}

@app.get("/", response_class=HTMLResponse)
def dashboard():
    return """
    <!DOCTYPE html>
    <html lang="pt-BR">
    <head>
        <meta charset="UTF-8">
        <title>Truffle Finder - Terminal Ibovespa Total</title>
        <script src="https://cdn.tailwindcss.com"></script>
    </head>
    <body class="bg-slate-900 text-slate-100 font-sans p-6">
        <div class="max-w-7xl mx-auto">
            <header class="flex justify-between items-center mb-8 border-b border-slate-700 pb-4">
                <div>
                    <h1 class="text-3xl font-bold text-amber-400">🍄 Truffle Finder</h1>
                    <p class="text-slate-400">Terminal de Coleta e Análise de Sentimento - Cobertura Completa Ibovespa</p>
                </div>
                <div id="status-badge" class="bg-emerald-600 px-4 py-2 rounded-lg text-sm font-semibold">
                    Sistema Ativo (Ibovespa Total)
                </div>
            </header>

            <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                <div class="bg-slate-800 p-6 rounded-xl border border-slate-700">
                    <h3 class="text-slate-400 text-sm font-medium">Empresas Monitoradas</h3>
                    <p id="total-empresas" class="text-3xl font-bold text-white mt-2">Carregando...</p>
                </div>
                <div class="bg-slate-800 p-6 rounded-xl border border-slate-700">
                    <h3 class="text-slate-400 text-sm font-medium">Notícias Coletadas (RSS Real)</h3>
                    <p id="total-noticias" class="text-3xl font-bold text-amber-400 mt-2">Carregando...</p>
                </div>
                <div class="bg-slate-800 p-6 rounded-xl border border-slate-700">
                    <h3 class="text-slate-400 text-sm font-medium">Fontes Ativas</h3>
                    <p class="text-3xl font-bold text-blue-400 mt-2">Valor & InfoMoney</p>
                </div>
            </div>

            <div class="bg-slate-800 rounded-xl border border-slate-700 p-6">
                <h2 class="text-xl font-bold mb-4 text-slate-200">Fluxo de Notícias em Tempo Real por Ticker</h2>
                <div class="overflow-x-auto">
                    <table class="w-full text-left border-collapse">
                        <thead>
                            <tr class="border-b border-slate-700 text-slate-400 text-sm">
                                <th class="p-3">Data</th>
                                <th class="p-3">Ticker / Ativo</th>
                                <th class="p-3">Setor</th>
                                <th class="p-3">Título da Notícia</th>
                                <th class="p-3">Sentimento (NLP)</th>
                            </tr>
                        </thead>
                        <tbody id="tabela-noticias" class="divide-y divide-slate-700 text-sm">
                            <tr><td colspan="5" class="p-4 text-center text-slate-400">Buscando feeds do mercado...</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <script>
            async function carregarDados() {
                try {
                    const res = await fetch('/api/noticias');
                    const data = await res.json();
                    
                    document.getElementById('total-empresas').innerText = data.total_empresas_monitoradas + " Ativos";
                    document.getElementById('total-noticias').innerText = data.noticias.length;
                    
                    const tbody = document.getElementById('tabela-noticias');
                    tbody.innerHTML = '';
                    
                    if(data.noticias.length === 0) {
                        tbody.innerHTML = '<tr><td colspan="5" class="p-4 text-center text-slate-400">Nenhuma notícia encontrada no momento.</td></tr>';
                        return;
                    }
                    
                    data.noticias.forEach(n => {
                        let badgeColor = 'bg-slate-700 text-slate-300';
                        if(n.sentimento === 'Positivo') badgeColor = 'bg-emerald-900 text-emerald-300';
                        if(n.sentimento === 'Negativo') badgeColor = 'bg-rose-900 text-rose-300';
                        
                        const tr = document.createElement('tr');
                        tr.innerHTML = `
                            <td class="p-3 text-slate-400 whitespace-nowrap">${n.data.substring(0, 16)}</td>
                            <td class="p-3 font-bold text-amber-400">${n.ticker}</td>
                            <td class="p-3 text-slate-300">${n.setor}</td>
                            <td class="p-3"><a href="${n.link}" target="_blank" class="hover:underline text-slate-100">${n.titulo}</a></td>
                            <td class="p-3"><span class="px-2.5 py-1 rounded-full text-xs font-semibold ${badgeColor}">${n.sentimento}</span></td>
                        `;
                        tbody.appendChild(tr);
                    });
                } catch (err) {
                    console.error("Erro ao carregar dados:", err);
                }
            }
            carregarDados();
            setInterval(carregarDados, 60000); // Atualiza a cada 1 minuto
        </script>
    </body>
    </html>
    """
