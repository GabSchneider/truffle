from fastapi import FastAPI, HTTPException
from fastapi.responses import HTMLResponse
import feedparser
from datetime import datetime
import sqlite3

app = FastAPI(title="Truffle Finder - Terminal Ibovespa Histórico", version="4.0")

# Inicialização e Configuração do Banco de Dados SQLite na VPS
DB_FILE = "truffle_history.db"

def init_db():
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS noticias (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            titulo TEXT UNIQUE,
            fonte TEXT,
            data TEXT,
            link TEXT,
            ticker TEXT,
            setor TEXT,
            sentimento TEXT,
            criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    conn.commit()
    conn.close()

init_db()

IBOV_MAPA = {
    "PETR4": {"nome": "Petrobras PN", "setor": "Petróleo, Gás e Biocombustíveis"},
    "PETR3": {"nome": "Petrobras ON", "setor": "Petróleo, Gás e Biocombustíveis"},
    "VALE3": {"nome": "Vale", "setor": "Mineração / Materiais Básicos"},
    "ITUB4": {"nome": "Itaú Unibanco", "setor": "Financeiro"},
    "BBDC4": {"nome": "Bradesco", "setor": "Financeiro"},
    "BBAS3": {"nome": "Banco do Brasil", "setor": "Financeiro"},
    "SANB11": {"nome": "Santander Brasil", "setor": "Financeiro"},
    "B3SA3": {"nome": "B3 S.A.", "setor": "Serviços Financeiros Diversos"},
    "ABEV3": {"nome": "Ambev", "setor": "Consumo Não Cíclico"},
    "MGLU3": {"nome": "Magazine Luiza", "setor": "Consumo Cíclico"},
    "RENT3": {"nome": "Localiza", "setor": "Consumo Cíclico"},
    "WEGE3": {"nome": "Weg", "setor": "Bens Industriais"},
    "SUZB3": {"nome": "Suzano", "setor": "Papel e Celulose"},
    "JBSS3": {"nome": "JBS", "setor": "Consumo Não Cíclico"},
    "PRIO3": {"nome": "Prio", "setor": "Petróleo, Gás e Biocombustíveis"},
    "ELET3": {"nome": "Eletrobras", "setor": "Utilidade Pública"},
    "EQTL3": {"nome": "Equatorial", "setor": "Utilidade Pública"},
    "CPLE6": {"nome": "Copel", "setor": "Utilidade Pública"}
}

RSS_FEEDS = [
    "https://infomoney.com.br/feed/",
    "https://valor.globo.com/rss/"
]

def analisar_sentimento(texto: str) -> str:
    texto_lower = texto.lower()
    positivas = ["alta", "lucro", "crescimento", "disparou", "positivo", "superou", "recorde", "expansão", "dividendo", "valorização", "avanço"]
    negativas = ["queda", "prejuízo", "crise", "despencou", "negativo", "investigação", "falência", "corte", "processo", "retração"]
    
    score = 0
    for p in positivas:
        if p in texto_lower: score += 1
    for n in negativas:
        if n in texto_lower: score -= 1
            
    if score > 0: return "Positivo"
    elif score < 0: return "Negativo"
    return "Neutro"

def sincronizar_feeds():
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    
    novas_inseridas = 0
    for url_feed in RSS_FEEDS:
        try:
            feed = feedparser.parse(url_feed)
            for entry in feed.entries[:25]:
                titulo = entry.get("title", "")
                link = entry.get("link", "")
                data_pub = entry.get("published", str(datetime.now()))[:16]
                
                ticker_encontrado = "IBOV / MERCADO"
                setor_encontrado = "Índice Bovespa"
                
                for ticker, info in IBOV_MAPA.items():
                    if ticker.lower() in titulo.lower() or info["nome"].lower() in titulo.lower():
                        ticker_encontrado = ticker
                        setor_encontrado = info["setor"]
                        break
                
                sentimento = analisar_sentimento(titulo)
                fonte_nome = "InfoMoney" if "infomoney" in url_feed else "Valor Econômico"
                
                try:
                    cursor.execute('''
                        INSERT INTO noticias (titulo, fonte, data, link, ticker, setor, sentimento)
                        VALUES (?, ?, ?, ?, ?, ?, ?)
                    ''', (titulo, fonte_nome, data_pub, link, ticker_encontrado, setor_encontrado, sentimento))
                    novas_inseridas += 1
                except sqlite3.IntegrityError:
                    pass # Já existe no banco (evita duplicadas)
        except Exception:
            continue
            
    conn.commit()
    conn.close()
    return novas_inseridas

@app.get("/api/noticias")
def obter_noticias():
    # Sincroniza dados novos ao requisitar
    sincronizar_feeds()
    
    conn = sqlite3.connect(DB_FILE)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM noticias ORDER BY id DESC LIMIT 50")
    rows = cursor.fetchall()
    
    noticias = [dict(row) for row in rows]
    conn.close()
    
    return {
        "status": "sucesso", 
        "total_empresas": len(IBOV_MAPA), 
        "total_historico": len(noticias), 
        "noticias": noticias
    }

@app.get("/", response_class=HTMLResponse)
def dashboard():
    return """
    <!DOCTYPE html>
    <html lang="pt-BR">
    <head>
        <meta charset="UTF-8">
        <title>Truffle Finder - Terminal Institucional Ibovespa</title>
        <script src="https://cdn.tailwindcss.com"></script>
    </head>
    <body class="bg-slate-950 text-slate-100 font-sans p-6">
        <div class="max-w-7xl mx-auto">
            <header class="flex justify-between items-center mb-8 border-b border-slate-800 pb-4">
                <div class="flex items-center gap-3">
                    <div class="bg-blue-600/20 p-3 rounded-xl border border-blue-500/30 text-2xl">🐷</div>
                    <div>
                        <h1 class="text-2xl font-bold text-blue-400">TRUFFLE FINDER</h1>
                        <p class="text-xs text-slate-400 uppercase tracking-widest">Terminal de Inteligência de Mercado B3</p>
                    </div>
                </div>
                <div class="flex items-center gap-3">
                    <span class="inline-flex items-center gap-1.5 bg-emerald-950 text-emerald-400 px-3 py-1.5 rounded-full text-xs font-semibold border border-emerald-800">
                        <span class="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span> Banco SQLite Ativo
                    </span>
                </div>
            </header>

            <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                <div class="bg-slate-900 p-6 rounded-xl border border-slate-800 shadow-lg">
                    <h3 class="text-slate-400 text-xs uppercase tracking-wider font-semibold">Ativos Monitorados</h3>
                    <p id="total-empresas" class="text-3xl font-bold text-white mt-2">Carregando...</p>
                </div>
                <div class="bg-slate-900 p-6 rounded-xl border border-slate-800 shadow-lg">
                    <h3 class="text-slate-400 text-xs uppercase tracking-wider font-semibold">Histórico Armazenado</h3>
                    <p id="total-noticias" class="text-3xl font-bold text-blue-400 mt-2">Carregando...</p>
                </div>
                <div class="bg-slate-900 p-6 rounded-xl border border-slate-800 shadow-lg">
                    <h3 class="text-slate-400 text-xs uppercase tracking-wider font-semibold">Persistência & Segurança</h3>
                    <p class="text-3xl font-bold text-emerald-400 mt-2">Ativa (VPS)</p>
                </div>
            </div>

            <div class="bg-slate-900 rounded-xl border border-slate-800 p-6 shadow-xl">
                <div class="flex justify-between items-center mb-6">
                    <h2 class="text-lg font-bold text-slate-200">Base Histórica de Notícias e NLP</h2>
                    <button onclick="carregarDados()" class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-xs font-semibold transition">Atualizar Dados</button>
                </div>
                <div class="overflow-x-auto">
                    <table class="w-full text-left border-collapse">
                        <thead>
                            <tr class="border-b border-slate-800 text-slate-400 text-xs uppercase tracking-wider">
                                <th class="p-3">Data / Hora</th>
                                <th class="p-3">Ticker</th>
                                <th class="p-3">Setor</th>
                                <th class="p-3">Título da Notícia</th>
                                <th class="p-3">Sentimento (NLP)</th>
                            </tr>
                        </thead>
                        <tbody id="tabela-noticias" class="divide-y divide-slate-800/60 text-sm">
                            <tr><td colspan="5" class="p-6 text-center text-slate-500">A carregar registos do banco de dados...</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <script>
            async function carregarDados() {
                try {
                    const res = await fetch('/api/noticias');
                    const data = await res.json();
                    
                    document.getElementById('total-empresas').innerText = data.total_empresas + " Empresas";
                    document.getElementById('total-noticias').innerText = data.total_historico + " Registos";
                    
                    const tbody = document.getElementById('tabela-noticias');
                    tbody.innerHTML = '';
                    
                    if(data.noticias.length === 0) {
                        tbody.innerHTML = '<tr><td colspan="5" class="p-6 text-center text-slate-500">Nenhum registo encontrado no banco de dados.</td></tr>';
                        return;
                    }
                    
                    data.noticias.forEach(n => {
                        let badgeColor = 'bg-slate-800 text-slate-300 border-slate-700';
                        if(n.sentimento === 'Positivo') badgeColor = 'bg-emerald-950 text-emerald-400 border-emerald-800';
                        if(n.sentimento === 'Negativo') badgeColor = 'bg-rose-950 text-rose-400 border-rose-800';
                        
                        const tr = document.createElement('tr');
                        tr.className = 'hover:bg-slate-800/40 transition';
                        tr.innerHTML = `
                            <td class="p-3 text-slate-400 text-xs whitespace-nowrap">${n.data}</td>
                            <td class="p-3 font-mono font-bold text-blue-400">${n.ticker}</td>
                            <td class="p-3 text-slate-300 text-xs">${n.setor}</td>
                            <td class="p-3"><a href="${n.link}" target="_blank" class="hover:text-blue-400 transition text-slate-100">${n.titulo}</a></td>
                            <td class="p-3"><span class="px-3 py-1 rounded-full text-xs font-semibold border ${badgeColor}">${n.sentimento}</span></td>
                        `;
                        tbody.appendChild(tr);
                    });
                } catch (err) {
                    console.error("Erro ao carregar dados:", err);
                }
            }
            carregarDados();
        </script>
    </body>
    </html>
    """
