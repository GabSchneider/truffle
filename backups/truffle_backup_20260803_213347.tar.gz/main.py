from fastapi import FastAPI
from fastapi.responses import HTMLResponse
from database import init_db, buscar_noticias
from nlp import processar_feeds

app = FastAPI(title="Truffle Finder - Terminal Institucional Modular", version="13.0")

init_db()

@app.get("/api/dados")
def api_dados(ticker: str = "TODOS"):
    processar_feeds()
    noticias, total, estatisticas, setores = buscar_noticias(ticker)
    return {
        "status": "sucesso",
        "total": total,
        "estatisticas": estatisticas,
        "setores": setores,
        "noticias": noticias
    }

@app.get("/", response_class=HTMLResponse)
def index():
    return """
    <!DOCTYPE html>
    <html lang="pt-BR">
    <head>
        <meta charset="UTF-8">
        <title>Truffle Finder - Terminal Institucional B3</title>
        <script src="https://cdn.tailwindcss.com"></script>
        <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    </head>
    <body class="bg-slate-950 text-slate-100 font-sans flex h-screen overflow-hidden">
        <aside class="w-72 bg-slate-900 border-r border-slate-800 flex flex-col justify-between p-6 shadow-2xl">
            <div>
                <div class="flex items-center gap-3 mb-8 pb-4 border-b border-slate-800">
                    <div class="bg-gradient-to-br from-blue-600/30 to-blue-900/40 p-2.5 rounded-2xl border border-blue-500/40 shadow flex items-center justify-center">
                        <span class="text-2xl">🐷</span>
                    </div>
                    <div>
                        <h1 class="text-base font-black tracking-wider text-white">TRUFFLE<span class="text-blue-500">FINDER</span></h1>
                        <p class="text-[10px] text-slate-400 uppercase tracking-widest font-semibold">Modular Terminal</p>
                    </div>
                </div>

                <div class="space-y-6">
                    <div>
                        <p class="text-[10px] font-bold uppercase tracking-widest text-slate-400 mb-3">Módulos</p>
                        <nav class="space-y-1.5">
                            <button onclick="mudarModulo('dashboard')" id="btn-dashboard" class="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-xs font-semibold bg-blue-600 text-white transition text-left shadow">📊 Dashboard Executivo</button>
                            <button onclick="mudarModulo('fontes')" id="btn-fontes" class="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-xs font-semibold text-slate-400 hover:bg-slate-800 hover:text-white transition text-left">🔍 Classificação de Fontes</button>
                        </nav>
                    </div>

                    <div>
                        <p class="text-[10px] font-bold uppercase tracking-widest text-slate-400 mb-3">Filtro Rápido</p>
                        <div class="grid grid-cols-2 gap-1.5">
                            <button onclick="filtrarTicker('TODOS')" class="px-2 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-xs font-mono text-slate-200 text-center transition ticker-btn shadow-inner" data-ticker="TODOS">🌐 TODOS</button>
                            <button onclick="filtrarTicker('PETR4')" class="px-2 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-xs font-mono text-slate-200 text-center transition ticker-btn" data-ticker="PETR4">⚡ PETR4</button>
                            <button onclick="filtrarTicker('VALE3')" class="px-2 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-xs font-mono text-slate-200 text-center transition ticker-btn" data-ticker="VALE3">⛏️ VALE3</button>
                            <button onclick="filtrarTicker('ITUB4')" class="px-2 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-xs font-mono text-slate-200 text-center transition ticker-btn" data-ticker="ITUB4">🏦 ITUB4</button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="pt-4 border-t border-slate-800 text-[11px] text-slate-500 flex justify-between items-center">
                <span>Arquitetura: Modular</span>
                <span class="text-emerald-400 font-semibold animate-pulse">● Online</span>
            </div>
        </aside>

        <main class="flex-1 flex flex-col overflow-y-auto p-8">
            <header class="flex justify-between items-center mb-8 pb-4 border-b border-slate-800">
                <div>
                    <h2 id="titulo-topo" class="text-2xl font-bold text-slate-100">Dashboard Executivo & Tese NLP</h2>
                    <p class="text-xs text-slate-400 mt-1">Filtro ativo: <span id="filtro-ativo-txt" class="text-blue-400 font-bold">TODOS</span></p>
                </div>
                <button onclick="carregarDados(tickerAtual)" class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-xs font-semibold transition shadow">🔄 Atualizar Terminal</button>
            </header>

            <div id="modulo-dashboard" class="space-y-6">
                <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div class="bg-slate-900 p-6 rounded-xl border border-slate-800 shadow">
                        <h3 class="text-slate-400 text-xs font-bold uppercase tracking-wider">Total de Artigos</h3>
                        <p id="stat-total" class="text-3xl font-bold text-white mt-2">-</p>
                    </div>
                    <div class="bg-slate-900 p-6 rounded-xl border border-slate-800 shadow">
                        <h3 class="text-slate-400 text-xs font-bold uppercase tracking-wider">Viés de Sentimento</h3>
                        <p id="stat-vies" class="text-3xl font-bold text-emerald-400 mt-2">Bullish</p>
                    </div>
                    <div class="bg-slate-900 p-6 rounded-xl border border-slate-800 shadow">
                        <h3 class="text-slate-400 text-xs font-bold uppercase tracking-wider">Ativo em Foco</h3>
                        <p id="stat-ativo-card" class="text-3xl font-bold text-blue-400 mt-2">TODOS</p>
                    </div>
                </div>

                <div class="bg-slate-900 p-6 rounded-xl border border-slate-800 shadow">
                    <h3 class="text-sm font-bold text-slate-200 mb-4">📈 Tese Analítica: Distribuição de Sentimento por NLP</h3>
                    <div style="height: 260px;"><canvas id="graficoNLP"></canvas></div>
                </div>

                <div class="bg-slate-900 rounded-xl border border-slate-800 p-6 shadow">
                    <h3 class="text-sm font-bold text-slate-200 mb-4">Stream de Notícias & Insights Lexicais</h3>
                    <div class="overflow-x-auto">
                        <table class="w-full text-left border-collapse">
                            <thead>
                                <tr class="border-b border-slate-800 text-slate-400 text-[11px] uppercase tracking-wider">
                                    <th class="p-3">Data</th>
                                    <th class="p-3">Ticker</th>
                                    <th class="p-3">Setor</th>
                                    <th class="p-3">Título & Link</th>
                                    <th class="p-3">Fonte</th>
                                    <th class="p-3">Sentimento (NLP)</th>
                                </tr>
                            </thead>
                            <tbody id="tabela-corpo" class="divide-y divide-slate-800/60 text-sm">
                                <tr><td colspan="6" class="p-6 text-center text-slate-500">A carregar registos...</td></tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <div id="modulo-fontes" class="hidden space-y-6">
                <div class="bg-slate-900 rounded-xl border border-slate-800 p-6">
                    <h3 class="text-lg font-bold text-slate-200 mb-4">🔍 Arquitetura Modular Ativa</h3>
                    <p class="text-xs text-slate-400">O projeto agora está dividido em `database.py`, `nlp.py` e `main.py`, garantindo manutenibilidade e zero riscos de regressão.</p>
                </div>
            </div>
        </main>

        <script>
            let tickerAtual = 'TODOS';
            let chartInstancia = null;

            function mudarModulo(mod) {
                ['dashboard', 'fontes'].forEach(m => {
                    document.getElementById(`modulo-${m}`).classList.add('hidden');
                    document.getElementById(`btn-${m}`).className = "w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-xs font-semibold text-slate-400 hover:bg-slate-800 hover:text-white transition text-left";
                });
                document.getElementById(`modulo-${mod}`).classList.remove('hidden');
                document.getElementById(`btn-${mod}`).className = "w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-xs font-semibold bg-blue-600 text-white transition text-left shadow";
            }

            async function carregarDados(ticker = 'TODOS') {
                tickerAtual = ticker;
                document.getElementById('filtro-ativo-txt').innerText = ticker;
                document.getElementById('stat-ativo-card').innerText = ticker;
                
                try {
                    const res = await fetch(`/api/dados?ticker=${ticker}`);
                    const data = await res.json();
                    
                    document.getElementById('stat-total').innerText = data.total;
                    
                    const tbody = document.getElementById('tabela-corpo');
                    tbody.innerHTML = '';
                    
                    if(data.noticias.length === 0) {
                        tbody.innerHTML = '<tr><td colspan="6" class="p-6 text-center text-slate-500">Nenhum registo encontrado.</td></tr>';
                        return;
                    }
                    
                    data.noticias.forEach(n => {
                        let badge = 'bg-slate-800 text-slate-300 border-slate-700';
                        if(n.sentimento === 'Positivo') badge = 'bg-emerald-950 text-emerald-400 border-emerald-800';
                        if(n.sentimento === 'Negativo') badge = 'bg-rose-950 text-rose-400 border-rose-800';
                        
                        const tr = document.createElement('tr');
                        tr.className = 'hover:bg-slate-800/40 transition';
                        tr.innerHTML = `
                            <td class="p-3 text-slate-400 text-xs whitespace-nowrap">${n.data}</td>
                            <td class="p-3 font-mono font-bold text-blue-400">${n.ticker}</td>
                            <td class="p-3 text-slate-300 text-xs">${n.setor}</td>
                            <td class="p-3"><a href="${n.link}" target="_blank" class="hover:text-blue-400 transition text-slate-100">${n.titulo}</a></td>
                            <td class="p-3 text-xs text-slate-400">${n.fonte}</td>
                            <td class="p-3"><span class="px-2.5 py-1 rounded-full text-xs font-semibold border ${badge}">${n.sentimento} (${n.score_nlp})</span></td>
                        `;
                        tbody.appendChild(tr);
                    });

                    renderizarGrafico(data.estatisticas);
                } catch (err) { console.error(err); }
            }

            function filtrarTicker(t) { carregarDados(t); }

            function renderizarGrafico(estat) {
                const ctx = document.getElementById('graficoNLP').getContext('2d');
                if(chartInstancia) chartInstancia.destroy();
                chartInstancia = new Chart(ctx, {
                    type: 'bar',
                    data: {
                        labels: ['Positivo (Bullish)', 'Neutro', 'Negativo (Bearish)'],
                        datasets: [{ data: [estat.positivo, estat.neutro, estat.negativo], backgroundColor: ['#10B981', '#F59E0B', '#EF4444'], borderRadius: 6 }]
                    },
                    options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } } }
                });
            }

            carregarDados('TODOS');
        </script>
    </body>
    </html>
    """
