import sqlite3

DB_FILE = "truffle_institutional.db"

def init_db():
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS noticias (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            titulo TEXT UNIQUE,
            fonte TEXT,
            data TEXT,
            link TEXT,
            ticker TEXT,
            setor TEXT,
            sentimento TEXT,
            score_nlp REAL
        )
    ''')
    conn.commit()
    conn.close()

def salvar_noticia(n):
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    try:
        cursor.execute('''
            INSERT INTO noticias (titulo, fonte, data, link, ticker, setor, sentimento, score_nlp)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ''', (n["titulo"], n["fonte"], n["data"], n["link"], n["ticker"], n["setor"], n["sentimento"], n["score_nlp"]))
        conn.commit()
    except sqlite3.IntegrityError:
        pass
    conn.close()

def buscar_noticias(ticker=None):
    conn = sqlite3.connect(DB_FILE)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    if ticker and ticker != "TODOS":
        cursor.execute("SELECT * FROM noticias WHERE ticker = ? ORDER BY id DESC LIMIT 50", (ticker,))
    else:
        cursor.execute("SELECT * FROM noticias ORDER BY id DESC LIMIT 50")
    rows = cursor.fetchall()
    noticias = [dict(r) for r in rows]
    
    cursor.execute("SELECT COUNT(*) FROM noticias")
    total = cursor.fetchone()[0]
    cursor.execute("SELECT COUNT(*) FROM noticias WHERE sentimento='Positivo'")
    pos = cursor.fetchone()[0]
    cursor.execute("SELECT COUNT(*) FROM noticias WHERE sentimento='Negativo'")
    neg = cursor.fetchone()[0]
    
    cursor.execute("SELECT setor, COUNT(*) as total FROM noticias GROUP BY setor")
    setores = {row["setor"]: row["total"] for row in cursor.fetchall()}
    
    conn.close()
    return noticias, total, {"positivo": pos, "negativo": neg, "neutro": max(total - pos - neg, 0)}, setores
