import sqlite3

DB_FILE = "truffle_institutional.db"

def init_db():
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS noticias (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            titulo TEXT UNIQUE,
            fonte TEXT,
            data TEXT,
            link TEXT,
            ticker TEXT,
            setor TEXT,
            sentimento TEXT,
            score_nlp REAL
        )
    ''')
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS preferencias (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT,
            setor_alerta TEXT,
            sensibilidade TEXT
        )
    ''')
    cursor.execute("SELECT COUNT(*) FROM preferencias")
    if cursor.fetchone()[0] == 0:
        cursor.execute("INSERT INTO preferencias (email, setor_alerta, sensibilidade) VALUES (?, ?, ?)", 
                       ("gestor@trufflefinder.com.br", "Financeiro", "Alta"))
    conn.commit()
    conn.close()

def salvar_noticia(n):
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    try:
        cursor.execute('''
            INSERT INTO noticias (titulo, fonte, data, link, ticker, setor, sentimento, score_nlp)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ''', (n["titulo"], n["fonte"], n["data"], n["link"], n["ticker"], n["setor"], n["sentimento"], n["score_nlp"]))
        conn.commit()
    except sqlite3.IntegrityError:
        pass
    conn.close()

def buscar_dados_completos(ticker=None):
    conn = sqlite3.connect(DB_FILE)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    
    if ticker and ticker != "TODOS":
        cursor.execute("SELECT * FROM noticias WHERE ticker = ? ORDER BY id DESC LIMIT 50", (ticker,))
    else:
        cursor.execute("SELECT * FROM noticias ORDER BY id DESC LIMIT 50")
        
    rows = cursor.fetchall()
    noticias = [dict(r) for r in rows]
    
    # Mocks iniciais se o banco estiver vazio
    if not noticias:
        mock_iniciais = [
            {"titulo": "Petrobras (PETR4) anuncia alta na produção do pré-sal", "fonte": "Valor Econômico", "data": "03/08 21:00", "link": "https://valor.globo.com", "ticker": "PETR4", "setor": "Petróleo, Gás e Biocombustíveis", "sentimento": "Positivo", "score_nlp": 0.85},
            {"titulo": "Vale (VALE3) relata estabilidade nos contratos de minério", "fonte": "InfoMoney", "data": "03/08 20:30", "link": "https://infomoney.com.br", "ticker": "VALE3", "setor": "Materiais Básicos", "sentimento": "Neutro", "score_nlp": 0.05},
            {"titulo": "Itaú Unibanco (ITUB4) expande crédito e supera expectativas", "fonte": "Valor Econômico", "data": "03/08 19:15", "link": "https://valor.globo.com", "ticker": "ITUB4", "setor": "Financeiro", "sentimento": "Positivo", "score_nlp": 0.75},
            {"titulo": "Magazine Luiza (MGLU3) lida com pressões no e-commerce", "fonte": "InfoMoney", "data": "03/08 18:00", "link": "https://infomoney.com.br", "ticker": "MGLU3", "setor": "Consumo Cíclico", "sentimento": "Negativo", "score_nlp": -0.65}
        ]
        for m in mock_iniciais:
            salvar_noticia(m)
        
        if ticker and ticker != "TODOS":
            cursor.execute("SELECT * FROM noticias WHERE ticker = ? ORDER BY id DESC LIMIT 50", (ticker,))
        else:
            cursor.execute("SELECT * FROM noticias ORDER BY id DESC LIMIT 50")
        rows = cursor.fetchall()
        noticias = [dict(r) for r in rows]

    cursor.execute("SELECT COUNT(*) FROM noticias")
    total = cursor.fetchone()[0]
    cursor.execute("SELECT COUNT(*) FROM noticias WHERE sentimento='Positivo'")
    pos = cursor.fetchone()[0]
    cursor.execute("SELECT COUNT(*) FROM noticias WHERE sentimento='Negativo'")
    neg = cursor.fetchone()[0]
    
    cursor.execute("SELECT setor, COUNT(*) as total FROM noticias GROUP BY setor")
    setores = {row["setor"]: row["total"] for row in cursor.fetchall()}
    
    cursor.execute("SELECT * FROM preferencias ORDER BY id DESC LIMIT 1")
    pref_row = cursor.fetchone()
    preferencias = dict(pref_row) if pref_row else {"email": "", "setor_alerta": "", "sensibilidade": "Alta"}

    conn.close()
    return noticias, total, {"positivo": pos, "negativo": neg, "neutro": max(total - pos - neg, 0)}, setores, preferencias

def salvar_preferencias(email, setor_alerta, sensibilidade):
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    cursor.execute("INSERT INTO preferencias (email, setor_alerta, sensibilidade) VALUES (?, ?, ?)", (email, setor_alerta, sensibilidade))
    conn.commit()
    conn.close()
