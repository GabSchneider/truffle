from flask import Flask, render_template_string, jsonify, request, session, redirect, url_for
from database import inicializar_db, listar_noticias, buscar_estatisticas, limpar_banco, sqlite3, DB_FILE
from nlp import processar_feeds, IBOV_MAPA
from datetime import datetime, timedelta
import random

app = Flask(__name__)
app.secret_key = "truffle_finder_secret_key_institucional"
inicializar_db()

def init_feedback_db():
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS feedback_humano (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            noticia_id INTEGER,
            titulo TEXT,
            sentimento_ia TEXT,
            sentimento_humano TEXT,
            justificativa TEXT,
            usuario TEXT,
            criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS usuarios (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT UNIQUE,
            papel TEXT
        )
    ''')
    cursor.execute("SELECT COUNT(*) FROM usuarios")
    if cursor.fetchone()[0] == 0:
        cursor.execute("INSERT INTO usuarios (email, papel) VALUES (?, ?)", ("admin@truffle.com", "Admin"))
        cursor.execute("INSERT INTO usuarios (email, papel) VALUES (?, ?)", ("analista@truffle.com", "Truffle"))
        cursor.execute("INSERT INTO usuarios (email, papel) VALUES (?, ?)", ("cliente@empresa.com", "Comum"))
    conn.commit()
    conn.close()

init_feedback_db()

HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Truffle Finder | Terminal Institucional B3</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        :root {
            --bg-color: #0f172a;
            --card-bg: #1e293b;
            --text-primary: #f8fafc;
            --text-secondary: #94a3b8;
            --accent-green: #22c55e;
            --accent-red: #ef4444;
            --accent-blue: #3b82f6;
            --border-color: #334155;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: var(--bg-color);
            color: var(--text-primary);
            margin: 0;
            display: flex;
            height: 100vh;
            overflow: hidden;
        }
        aside {
            width: 260px;
            background-color: #090d16;
            border-right: 1px solid var(--border-color);
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            padding: 20px;
        }
        .logo { font-size: 18px; font-weight: bold; color: #38bdf8; margin-bottom: 30px; letter-spacing: 1px; }
        .nav-links { display: flex; flex-direction: column; gap: 8px; }
        .nav-links button {
            background: transparent;
            color: var(--text-secondary);
            border: none;
            text-align: left;
            padding: 10px 12px;
            border-radius: 6px;
            cursor: pointer;
            font-weight: 600;
            font-size: 14px;
        }
        .nav-links button:hover, .nav-links button.active {
            background-color: var(--card-bg);
            color: var(--text-primary);
        }
        .user-profile {
            background: var(--card-bg);
            padding: 10px;
            border-radius: 6px;
            font-size: 12px;
            border: 1px solid var(--border-color);
        }
        main {
            flex: 1;
            padding: 30px;
            overflow-y: auto;
        }
        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid var(--border-color);
            padding-bottom: 15px;
            margin-bottom: 25px;
        }
        h2 { margin: 0; font-size: 22px; color: #38bdf8; }
        .controls { display: flex; gap: 10px; align-items: center; }
        button, select {
            background-color: var(--card-bg);
            color: var(--text-primary);
            border: 1px solid var(--border-color);
            padding: 8px 14px;
            border-radius: 6px;
            cursor: pointer;
            font-weight: 600;
        }
        button:hover { background-color: #334155; }
        button.primary { background-color: #0284c7; border-color: #0369a1; }
        .grid-container {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 20px;
            margin-bottom: 25px;
        }
        @media(max-width: 1024px) { .grid-container { grid-template-columns: 1fr; } }
        .card {
            background-color: var(--card-bg);
            border: 1px solid var(--border-color);
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }
        .card h3 { margin-top: 0; color: #38bdf8; border-bottom: 1px solid var(--border-color); padding-bottom: 10px; }
        .news-table { width: 100%; border-collapse: collapse; font-size: 14px; }
        .news-table th, .news-table td { padding: 10px; text-align: left; border-bottom: 1px solid var(--border-color); }
        .badge { padding: 4px 8px; border-radius: 4px; font-size: 11px; font-weight: bold; }
        .badge-pos { background-color: rgba(34, 197, 94, 0.2); color: var(--accent-green); }
        .badge-neg { background-color: rgba(239, 68, 68, 0.2); color: var(--accent-red); }
        .badge-neu { background-color: rgba(148, 163, 184, 0.2); color: var(--text-secondary); }
        .chart-container { position: relative; height: 300px; width: 100%; }
        
        /* ESTILOS DOS BOTÕES DE PERÍODO */
        .period-selector { display: flex; gap: 6px; margin-bottom: 20px; }
        .period-btn {
            background-color: var(--card-bg);
            color: var(--text-secondary);
            border: 1px solid var(--border-color);
            padding: 6px 12px;
            border-radius: 6px;
            cursor: pointer;
            font-size: 12px;
            font-weight: 600;
        }
        .period-btn.active {
            background-color: #0284c7;
            color: white;
            border-color: #0369a1;
        }

        .hitl-card { background: #090d16; border: 1px solid #3b82f6; padding: 15px; border-radius: 8px; margin-bottom: 15px; }
        .hitl-actions { display: flex; gap: 10px; margin-top: 10px; }
        .btn-pos { background-color: rgba(34, 197, 94, 0.3); color: #22c55e; border-color: #22c55e; }
        .btn-neu { background-color: rgba(148, 163, 184, 0.3); color: #94a3b8; border-color: #94a3b8; }
        .btn-neg { background-color: rgba(239, 68, 68, 0.3); color: #ef4444; border-color: #ef4444; }
    </style>
</head>
<body>
    <aside>
        <div>
            <div class="logo">🥷 TRUFFLE FINDER</div>
            <div class="nav-links">
                <button onclick="mudarAba('dashboard')" id="nav-dashboard" class="active">📊 Dashboard Executivo</button>
                <button onclick="mudarAba('tendencia')" id="nav-tendencia">📈 Backtesting & Tendência</button>
                <button onclick="mudarAba('hitl')" id="nav-hitl" style="display: none; color: #38bdf8; border-left: 3px solid #38bdf8;">🧪 Teste de Realidade (HITL)</button>
            </div>
        </div>
        <div class="user-profile">
            <div style="margin-bottom: 5px;">Sessão Ativa:</div>
            <select id="perfilSelect" onchange="trocarPerfil(this.value)" style="width: 100%; font-size: 11px;">
                <option value="cliente@empresa.com">👤 Cliente Comum (Pagante)</option>
                <option value="analista@truffle.com">🔍 Analista Truffle (Interno)</option>
                <option value="admin@truffle.com">👑 Administrador</option>
            </select>
        </div>
    </aside>

    <main>
        <header>
            <h2 id="tituloAba">Dashboard Executivo Ibovespa</h2>
            <div class="controls">
                <button class="primary" onclick="atualizarFeed()">🔄 Sincronizar Feed</button>
            </div>
        </header>

        <div id="aba-dashboard">
            <div class="period-selector">
                <button onclick="mudarPeriodo('hoje')" class="period-btn" data-period="hoje">☀️ Hoje</button>
                <button onclick="mudarPeriodo('24h')" class="period-btn active" data-period="24h">⏳ Últimas 24h</button>
                <button onclick="mudarPeriodo('semana')" class="period-btn" data-period="semana">📅 Esta Semana</button>
                <button onclick="mudarPeriodo('mes')" class="period-btn" data-period="mes">📊 Este Mês</button>
                <button onclick="mudarPeriodo('ano')" class="period-btn" data-period="ano">📈 Este Ano</button>
            </div>

            <div class="grid-container">
                <div class="card">
                    <h3>⚡ Stream de Fatos & Gossips em Tempo Real</h3>
                    <div style="max-height: 380px; overflow-y: auto;">
                        <table class="news-table">
                            <thead>
                                <tr>
                                    <th>Data</th>
                                    <th>Ativo</th>
                                    <th>Título da Notícia</th>
                                    <th>Origem</th>
                                    <th>Sentimento (IA)</th>
                                </tr>
                            </thead>
                            <tbody id="tabelaNoticias"></tbody>
                        </table>
                    </div>
                </div>
                <div class="card">
                    <h3>📊 Sentimento por Setor</h3>
                    <div class="chart-container"><canvas id="setorChart"></canvas></div>
                </div>
            </div>
        </div>

        <div id="aba-tendencia" style="display: none;">
            <div class="card">
                <h3>📈 Backtesting da Tese & Linha de Tendência (EMA)</h3>
                <div class="chart-container" style="height: 380px;"><canvas id="tendenciaChart"></canvas></div>
            </div>
        </div>

        <div id="aba-hitl" style="display: none;">
            <div class="card">
                <h3>🧪 Teste de Realidade (Feedback Loop Humano - HITL)</h3>
                <p style="font-size: 13px; color: var(--text-secondary);">Avalie lote de 5 notícias aleatórias abaixo. Valide se a interpretação da IA condiz com a realidade do mercado B3.</p>
                <div id="hitlContainer">
                    <p style="text-align: center; color: var(--text-secondary);">A carregar lote de testes...</p>
                </div>
                <button class="primary" onclick="carregarSessaoHitl()" style="margin-top: 15px;">🔄 Gerar Novo Lote de 5 Notícias</button>
            </div>
        </div>
    </main>

    <script>
        let setorChartInstance = null;
        let tendenciaChartInstance = null;
        let periodoAtual = '24h';

        function mudarAba(aba) {
            ['dashboard', 'tendencia', 'hitl'].forEach(a => {
                document.getElementById(`aba-${a}`).style.display = 'none';
                document.getElementById(`nav-${a}`).classList.remove('active');
            });
            document.getElementById(`aba-${aba}`).style.display = 'block';
            document.getElementById(`nav-${aba}`).classList.add('active');

            const titulos = {
                'dashboard': 'Dashboard Executivo Ibovespa',
                'tendencia': 'Backtesting & Curvas de Tendência',
                'hitl': 'Teste de Realidade & Validação Humana (HITL)'
            };
            document.getElementById('tituloAba').innerText = titulos[aba];
            if(aba === 'hitl') carregarSessaoHitl();
        }

        function mudarPeriodo(periodo) {
            periodoAtual = periodo;
            document.querySelectorAll('.period-btn').forEach(btn => {
                if(btn.dataset.period === periodo) {
                    btn.classList.add('active');
                } else {
                    btn.classList.remove('active');
                }
            });
            carregarDados();
        }

        async function trocarPerfil(email) {
            const res = await fetch('/api/perfil', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({email: email})
            });
            const data = await res.json();
            const btnHitl = document.getElementById('nav-hitl');
            if(data.papel === 'Truffle' || data.papel === 'Admin') {
                btnHitl.style.display = 'block';
            } else {
                btnHitl.style.display = 'none';
                if(document.getElementById('aba-hitl').style.display === 'block') {
                    mudarAba('dashboard');
                }
            }
        }

        async function carregarDados() {
            const resNoticias = await fetch(`/api/noticias?periodo=${periodoAtual}`);
            const noticias = await resNoticias.json();
            atualizarTabela(noticias);

            const resStats = await fetch(`/api/estatisticas?periodo=${periodoAtual}`);
            const stats = await resStats.json();
            atualizarGraficoSetor(stats.por_setor);

            const resTendencia = await fetch(`/api/tendencia?dias=15`);
            const tendenciaData = await resTendencia.json();
            atualizarGraficoTendencia(tendenciaData);
        }

        function atualizarTabela(noticias) {
            const tbody = document.getElementById('tabelaNoticias');
            tbody.innerHTML = '';
            if(noticias.length === 0) {
                tbody.innerHTML = '<tr><td colspan="5" style="text-align: center; color: var(--text-secondary);">Nenhum registo encontrado para este período.</td></tr>';
                return;
            }
            noticias.forEach(n => {
                let badgeClass = n.sentimento === 'Positivo' ? 'badge-pos' : (n.sentimento === 'Negativo' ? 'badge-neg' : 'badge-neu');
                const tr = document.createElement('tr');
                tr.innerHTML = `
                    <td style="color: var(--text-secondary); font-size: 12px;">${n.data}</td>
                    <td><b>${n.ticker}</b></td>
                    <td><a href="${n.link}" target="_blank" style="color: #38bdf8; text-decoration: none;">${n.titulo}</a></td>
                    <td style="font-size: 12px;">${n.fonte}</td>
                    <td><span class="badge ${badgeClass}">${n.sentimento} (${n.score_nlp})</span></td>
                `;
                tbody.appendChild(tr);
            });
        }

        async function carregarSessaoHitl() {
            const res = await fetch('/api/hitl/lote');
            const lote = await res.json();
            const container = document.getElementById('hitlContainer');
            container.innerHTML = '';

            lote.forEach((item, index) => {
                const div = document.createElement('div');
                div.className = 'hitl-card';
                div.innerHTML = `
                    <div style="font-size: 12px; color: var(--text-secondary); margin-bottom: 5px;">Notícia #${index+1} | Ticker: <b>${item.ticker}</b> | IA Classificou: <b>${item.sentimento}</b></div>
                    <div style="font-size: 14px; font-weight: 600; margin-bottom: 10px;">${item.titulo}</div>
                    <div class="hitl-actions" id="actions-${item.id}">
                        <button class="btn-pos" onclick="enviarFeedback(${item.id}, 'Positivo', '${item.sentimento}')">🟢 Concordo (Positivo)</button>
                        <button class="btn-neu" onclick="enviarFeedback(${item.id}, 'Neutro', '${item.sentimento}')">⚪ Concordo (Neutro)</button>
                        <button class="btn-neg" onclick="enviarFeedback(${item.id}, 'Negativo', '${item.sentimento}')">🔴 Concordo (Negativo)</button>
                        <button onclick="pedirJustificativa(${item.id})" style="background:#ef4444; border:none; color:white;">⚠️ Diverge da IA</button>
                    </div>
                    <div id="just-box-${item.id}" style="margin-top: 10px; display:none;">
                        <input type="text" id="input-just-${item.id}" placeholder="Justifique o porquê da divergência humana..." style="width: 70%; padding: 6px;">
                        <button class="primary" onclick="salvarDivergencia(${item.id}, '${item.sentimento}')">Enviar Feedback</button>
                    </div>
                `;
                container.appendChild(div);
            });
        }

        async function enviarFeedback(noticiaId, sentimentoHumano, sentimentoIa) {
            await fetch('/api/hitl/feedback', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({noticia_id: noticiaId, sentimento_humano: sentimentoHumano, sentimento_ia: sentimentoIa, justificativa: 'Concorda com a IA'})
            });
            alert('Feedback registado com sucesso!');
        }

        function pedirJustificativa(noticiaId) {
            document.getElementById(`just-box-${noticiaId}`).style.display = 'block';
        }

        async function salvarDivergencia(noticiaId, sentimentoIa) {
            const justificativa = document.getElementById(`input-just-${noticiaId}`).value;
            const humano = prompt("Qual o julgamento correto? Digite: Positivo, Neutro ou Negativo");
            if(!humano) return;

            await fetch('/api/hitl/feedback', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({noticia_id: noticiaId, sentimento_humano: humano, sentimento_ia: sentimentoIa, justificativa: justificativa})
            });
            alert('Divergência registada no dataset de melhoria contínua!');
            carregarSessaoHitl();
        }

        function atualizarGraficoSetor(dadosSetor) {
            const ctx = document.getElementById('setorChart').getContext('2d');
            if (setorChartInstance) setorChartInstance.destroy();
            setorChartInstance = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: Object.keys(dadosSetor),
                    datasets: [{ data: Object.values(dadosSetor), backgroundColor: '#3b82f6', borderRadius: 4 }]
                },
                options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { y: { grid: { color: '#334155' }, ticks: { color: '#94a3b8' } }, x: { grid: { display: false }, ticks: { color: '#94a3b8', font: { size: 10 } } } } }
            });
        }

        function atualizarGraficoTendencia(data) {
            const ctx = document.getElementById('tendenciaChart').getContext('2d');
            if (tendenciaChartInstance) tendenciaChartInstance.destroy();
            tendenciaChartInstance = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: data.datas,
                    datasets: [
                        { label: 'IBOV Real', data: data.ibov, borderColor: '#22c55e', tension: 0.3, fill: true, backgroundColor: 'rgba(34,197,94,0.05)' },
                        { label: 'Tendência Preditiva (EMA)', data: data.tendencia_ema, borderColor: '#eab308', borderWidth: 2.5, tension: 0.4 }
                    ]
                },
                options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { labels: { color: '#f8fafc' } } }, scales: { y: { grid: { color: '#334155' }, ticks: { color: '#94a3b8' } }, x: { grid: { display: false }, ticks: { color: '#94a3b8' } } } }
            });
        }

        async function atualizarFeed() {
            await fetch('/api/atualizar', { method: 'POST' });
            carregarDados();
        }

        window.onload = () => {
            trocarPerfil('cliente@empresa.com');
            carregarDados();
        };
    </script>
</body>
</html>
"""

@app.route("/")
def index():
    return render_template_string(HTML_TEMPLATE)

@app.route("/api/perfil", methods=["POST"])
def api_perfil():
    data = request.json
    email = data.get("email")
    conn = sqlite3.connect(DB_FILE)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute("SELECT papel FROM usuarios WHERE email = ?", (email,))
    row = cursor.fetchone()
    conn.close()
    papel = row["papel"] if row else "Comum"
    session["email"] = email
    session["papel"] = papel
    return jsonify({"email": email, "papel": papel})

@app.route("/api/atualizar", methods=["POST"])
def api_atualizar():
    processar_feeds()
    return jsonify({"status": "sucesso"})

@app.route("/api/noticias")
def api_noticias():
    periodo = request.args.get("periodo", "24h")
    return jsonify(listar_noticias(periodo))

@app.route("/api/estatisticas")
def api_estatisticas():
    periodo = request.args.get("periodo", "24h")
    return jsonify(buscar_estatisticas(periodo))

@app.route("/api/tendencia")
def api_tendencia():
    dias = int(request.args.get("dias", 15))
    datas, ibov_valores, tendencia_ema = [], [], []
    base_ibov = 125000.0
    hoje = datetime.now()
    for i in range(dias, -1, -1):
        d = hoje - timedelta(days=i)
        datas.append(d.strftime("%d/%m"))
        base_ibov += random.uniform(-1000, 1100)
        ibov_valores.append(round(base_ibov, 2))
    
    k = 2 / (len(ibov_valores) + 1)
    ema_atual = ibov_valores[0]
    for val in ibov_valores:
        ema_atual = (val * k) + (ema_atual * (1 - k))
        tendencia_ema.append(round(ema_atual, 2))

    return jsonify({"datas": datas, "ibov": ibov_valores, "tendencia_ema": tendencia_ema})

@app.route("/api/hitl/lote")
def api_hitl_lote():
    conn = sqlite3.connect(DB_FILE)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute("SELECT id, ticker, titulo, sentimento, score_nlp FROM noticias ORDER BY RANDOM() LIMIT 5")
    rows = cursor.fetchall()
    conn.close()
    return jsonify([dict(r) for r in rows])

@app.route("/api/hitl/feedback", methods=["POST"])
def api_hitl_feedback():
    data = request.json
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    cursor.execute('''
        INSERT INTO feedback_humano (noticia_id, sentimento_ia, sentimento_humano, justificativa, usuario)
        VALUES (?, ?, ?, ?, ?)
    ''', (
        data.get("noticia_id"),
        data.get("sentimento_ia"),
        data.get("sentimento_humano"),
        data.get("justificativa"),
        session.get("email", "anonimo")
    ))
    conn.commit()
    conn.close()
    return jsonify({"status": "feedback_registrado"})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
